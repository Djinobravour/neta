! function(n) {
    var t = {};

    function e(o) {
        if (t[o]) return t[o].exports;
        var i = t[o] = {
            i: o,
            l: !1,
            exports: {}
        };
        return n[o].call(i.exports, i, i.exports, e), i.l = !0, i.exports
    }
    e.m = n, e.c = t, e.d = function(n, t, o) {
        e.o(n, t) || Object.defineProperty(n, t, {
            enumerable: !0,
            get: o
        })
    }, e.r = function(n) {
        "undefined" != typeof Symbol && Symbol.toStringTag && Object.defineProperty(n, Symbol.toStringTag, {
            value: "Module"
        }), Object.defineProperty(n, "__esModule", {
            value: !0
        })
    }, e.t = function(n, t) {
        if (1 & t && (n = e(n)), 8 & t) return n;
        if (4 & t && "object" == typeof n && n && n.__esModule) return n;
        var o = Object.create(null);
        if (e.r(o), Object.defineProperty(o, "default", {
                enumerable: !0,
                value: n
            }), 2 & t && "string" != typeof n)
            for (var i in n) e.d(o, i, function(t) {
                return n[t]
            }.bind(null, i));
        return o
    }, e.n = function(n) {
        var t = n && n.__esModule ? function() {
            return n.default
        } : function() {
            return n
        };
        return e.d(t, "a", t), t
    }, e.o = function(n, t) {
        return Object.prototype.hasOwnProperty.call(n, t)
    }, e.p = "", e(e.s = 9)
}([function(n, t) {
    n.exports = function(n, t, e) {
        return t in n ? Object.defineProperty(n, t, {
            value: e,
            enumerable: !0,
            configurable: !0,
            writable: !0
        }) : n[t] = e, n
    }
}, function(n, t) {
    n.exports = function(n, t) {
        if (!(n instanceof t)) throw new TypeError("Cannot call a class as a function")
    }
}, function(n, t) {
    function e(n, t) {
        for (var e = 0; e < t.length; e++) {
            var o = t[e];
            o.enumerable = o.enumerable || !1, o.configurable = !0, "value" in o && (o.writable = !0), Object.defineProperty(n, o.key, o)
        }
    }
    n.exports = function(n, t, o) {
        return t && e(n.prototype, t), o && e(n, o), n
    }
}, function(n, t, e) {
    n.exports = e(8)
}, function(n, t, e) {
    var o = e(5),
        i = e(6),
        r = e(7);
    n.exports = function(n) {
        return o(n) || i(n) || r()
    }
}, function(n, t) {
    n.exports = function(n) {
        if (Array.isArray(n)) {
            for (var t = 0, e = new Array(n.length); t < n.length; t++) e[t] = n[t];
            return e
        }
    }
}, function(n, t) {
    n.exports = function(n) {
        if (Symbol.iterator in Object(n) || "[object Arguments]" === Object.prototype.toString.call(n)) return Array.from(n)
    }
}, function(n, t) {
    n.exports = function() {
        throw new TypeError("Invalid attempt to spread non-iterable instance")
    }
}, function(n, t, e) {
    var o;
    void 0 === (o = function() {
        var n = {},
            t = null,
            e = null,
            o = null,
            i = null,
            r = null,
            u = null,
            l = null,
            c = null,
            a = null,
            f = null,
            p = null,
            s = null,
            d = null,
            y = null,
            v = null,
            g = null,
            m = null,
            b = null,
            w = null,
            h = null,
            C = null,
            P = null,
            x = null,
            A = null,
            E = null,
            k = null,
            O = null,
            _ = null,
            D = null,
            S = null,
            T = null,
            j = null,
            R = null,
            L = null,
            B = null,
            I = null,
            N = null,
            M = null,
            V = null,
            F = null,
            U = null;

        function G(n, t) {
            "undefined" != typeof console && (void 0 !== t && console.log(t), void 0 !== n && console.log(n))
        }
        n.initBarreNavigation = function() {
                var n = {},
                    t = document.getElementById("natif-settings");
                if (t) return n.libelle = t.getAttribute("data-natif-title"), n.hasBack = "true" === t.getAttribute("data-natif-hasBack"), n.hasContextualMenuButton = "true" === t.getAttribute("data-natif-hasContextualMenuButton"), n.hasHelpButton = "true" === t.getAttribute("data-natif-hasHelpButton"), K("initBarreNavigation", Y(n))
            }, n.appelerTelephone = function(n) {
                var t = {};
                return t.numero = n, K("appelerTelephone", Y(t))
            }, n.ecrireMessage = function(n) {
                var t = {};
                return t.message = n, K("ecrireMessage", Y(t))
            }, n.tagMesureAudience = function(n, t, e, o) {
                var i;
                if ("object" == typeof n) i = n;
                else {
                    if ("string" != typeof n) return;
                    (i = {}).type = n, i.s2 = t, i.rub = e, o && (i.subRub = o)
                }
                return i.s2 && "string" == typeof i.s2 && (i.s2 = parseInt(i.s2)), K("tagMesureAudience", Y(i))
            }, n.menuContextuel = function(n, t, e) {
                var o = {};
                return M = "function" == typeof e ? e : null, o.titre = n, o.rubriques = t, K("menuContextuel", Y(o))
            }, n.callbackClickContextualMenuButton = function(n) {
                N = "function" == typeof n ? n : null
            }, n.tagCampagneBanniere = function(n, t) {
                var e = {};
                return e.type = n, e.campaignId = t, K("tagCampagneBanniere", Y(e))
            }, n.endWebview = function() {
                return K("endWebview", Y({}))
            }, n.ouvrirPDF = function(n) {
                var t = {};
                return t.url = n, K("ouvrirPDF", Y(t))
            }, n.ouvrirNavigateur = function(n) {
                var t = {};
                return t.url = n, K("ouvrirNavigateur", Y(t))
            }, n.GETSASObject = function(n) {
                l = "function" == typeof n ? n : null;
                return K("GETSASObject", Y({}))
            }, n.home = function() {
                return K("home", Y({}))
            }, n.getProfilTiers = function(n) {
                c = "function" == typeof n ? n : null;
                return K("getProfilTiers", Y({}))
            }, n.debranchement = function(e, o, i, r, u, l, c) {
                var a, f;
                if ("object" == typeof e) {
                    var p = e;
                    if (a = {}, p.callbackError)
                        for (var s in f = p.callbackError, p) p.hasOwnProperty(s) && "callbackError" !== s && (a[s] = p[s]);
                    else a = p
                } else {
                    if ("string" != typeof e) return;
                    if ((a = {}).DEB_idview = e, a.DEB_back = r, o && "" !== o && (a.DEB_url = o), i && "" !== i && (a.DEB_typeRequest = i), u && "" !== u) {
                        var d, y = {};
                        for (d = 0; d < u.length; d += 1)
                            if (y[u[d]] = "DPR" === e ? encodeURIComponent(l[d]) : l[d], "caracURL" === u[d]) {
                                if ("OAV" === e) y.caracURLencode = encodeURIComponent(l[d]);
                                else if ("CCA" === e) {
                                    var v = l[d];
                                    if (n.isVersionAppliGreaterThanEqual("5.0.0")) {
                                        delete y.caracURL;
                                        for (var g, m = /[?&]([^=#]+)=([^&#]*)/g; g = m.exec(v);) "b64_idPresta" === g[1] ? y.idPrestaTech = g[2] : "b64_numeroCarte" === g[1] && (y.numeroCarteTech = g[2])
                                    } else y.caracURLencode = encodeURIComponent(v)
                                }
                            } else "idPrestaTech" === u[d] && "999" === e && (y.idPrestaTech = encodeURIComponent(l[d]));
                            "CCA" === e && !n.isVersionAppliGreaterThanEqual("5.0.0") && y.idPrestaTech && y.numeroCarteTech && (y.caracURL = "/abm/restit/cartes/caracteristiques.json?b64_idPresta=" + y.idPrestaTech + "&b64_numeroCarte=" + y.numeroCarteTech, y.caracURLencode = encodeURIComponent(y.caracURL), delete y.idPrestaTech, delete y.numeroCarteTech), a.DEB_viewParams = y
                    }
                    f = c
                }
                return t = "function" == typeof f ? f : null, K("debranchement", Y(a))
            }, n.activerPassSecurite = function(n, t) {
                return C = "function" == typeof n ? n : null, P = "function" == typeof t ? t : null, K("activerPassSecurite", Y({}))
            }, n.typeCamera = function(n) {
                return n = "function" == typeof n ? n : null, K("typeCamera", Y({}))
            }, n.typeConnexion = function(n) {
                return V = "function" == typeof n ? n : null, K("typeConnexion", Y({}))
            }, n.disponibiliteAgent = function(n, t) {
                return F = "function" == typeof n ? n : null, U = "function" == typeof t ? t : null, K("disponibiliteAgent", Y({}))
            }, n.uploadFichier = function(n, t) {
                return k = "function" == typeof n ? n : null, O = "function" == typeof t ? t : null, K("uploadFichier")
            }, n.rotationPleinEcran = function(n, t, e, o) {
                var i = {};
                return b = "function" == typeof o ? o : null, "" !== n && (i.rotationBool = n), "" !== t && (i.pleinEcranBool = t), "" !== e && (i.paysageForceBool = e), K("rotationPleinEcran", Y(i))
            }, n.activateZoom = function(n, t, e) {
                var o = {};
                return A = "function" == typeof t ? t : null, E = "function" == typeof e ? e : null, "" !== n && (o.zoom = n), K("activateZoom", Y(o))
            }, n.ouvrirPopin = function(n, t, e, o, u, l) {
                var c = {};
                return i = "function" == typeof u ? u : null, r = "function" == typeof l ? l : null, c.texteMessage = n, c.typeMessage = t, c.libelleBouton1 = e, o && "" !== o && (c.libelleBouton2 = o), K("ouvrirPopin", Y(c))
            }, n.ouvrirPopinV2 = function(n, t, e, o, i, r, u) {
                var l = {};
                return p = "function" == typeof r ? r : null, l.typepopin = n, l.message = e, null !== t && "" !== t && (l.pictoName = t), null !== o && "" !== o && (l.boutons = o), null !== i && "" !== i && (l.display = i), null !== u && "" !== u && (l.height = u), K("ouvrirPopinV2", Y(l))
            }, n.getQRCodeScanParAppareilPhoto = function(n, t) {
                return e = "function" == typeof n ? n : null, o = "function" == typeof t ? t : null, K("getQRCodeScanParAppareilPhoto", Y({}))
            }, n.getQRCodeScanParFichier = function(n, t) {
                return e = "function" == typeof n ? n : null, o = "function" == typeof t ? t : null, K("getQRCodeScanParFichier", Y({}))
            }, n.showDatePicker = function(n, t, e, o) {
                var i = {};
                return i.datePre = n, i.dateMin = t, i.dateMax = e, u = "function" == typeof o ? o : null, K("showDatePicker", Y(i))
            }, n.tagAzure = function(n, t, e, o, i, r, u, l, c) {
                var a = {};
                return a.type = n, a.activity = t, a.error = e, a.event = o, a.appinfo = i, a.job = r, a.appinfovalue = u, a.extrainfoname = l, a.extrainfovalue = c, K("tagAzure", Y(a))
            }, n.tagKrux = function(n, t, e) {
                var o = {};
                if (o.pageName = n, t) {
                    for (var i = {}, r = 0; r < t.length; r += 1) {
                        var u = t[r].split("=");
                        i[u[0]] = u[1]
                    }
                    o.pageAttributes = i
                }
                if (e) {
                    for (i = {}, r = 0; r < e.length; r += 1) {
                        var l = e[r].split("=");
                        i[l[0]] = l[1]
                    }
                    o.userAttributes = i
                }
                return K("tagKrux", Y(o))
            }, n.selectionnerImage = function(t, e, o) {
                var i = function(n, t) {
                        return function(e, o) {
                            t(e, o), n.closeLoader()
                        }
                    },
                    r = function(n, t) {
                        return function() {
                            t(), n.closeLoader()
                        }
                    },
                    u = [];
                return t && (u = t), a = "function" == typeof e ? i(n, e) : n.closeLoader(), f = "function" == typeof o ? r(n, o) : n.closeLoader(), w = "function" == typeof e ? i(n, e) : n.closeLoader(), h = "function" == typeof o ? r(n, o) : n.closeLoader(), K("selectionnerImage", Y(u))
            }, n.priseDeVue = function(n, t) {
                return a = "function" == typeof n ? n : null, f = "function" == typeof t ? t : null, K("priseDeVue", Y({}))
            }, n.priseRDVCalendrier = function(n, t, e, o, i, r) {
                var u = {};
                return u.titre = n, u.lieu = t, u.descriptif = e, u.datedebut = o, u.datefin = i, u.datealarme = r, K("priseRDVCalendrier", Y(u))
            }, n.webviewReady = function(n) {
                I = "function" == typeof n ? n : null;
                navigator.userAgent.toLowerCase();
                J() || K("webviewReady", Y({}))
            }, n.prendreSelfie = function(n, t) {
                return s = "function" == typeof n ? n : null, d = "function" == typeof t ? t : null, K("prendreSelfie", Y({}))
            }, n.recupererImage = function(n, t) {
                return w = "function" == typeof n ? n : null, h = "function" == typeof t ? t : null, K("recupererImage", Y({}))
            }, n.demarrerDiscusion = function(n, t) {
                return y = "function" == typeof n ? n : null, v = "function" == typeof t ? t : null, K("demarrerDiscusion", Y({}))
            }, n.partagerVirement = function(n, t, e, o) {
                var i = {};
                return i.message = n, t && "" !== t && (i.pictoName = t), g = "function" == typeof e ? e : null, m = "function" == typeof o ? o : null, K("partagerVirement", Y(i))
            }, n.setWebviewReadyResponse = function(n) {
                I = "function" == typeof n ? n : null
            }, n.ouvrirGemstone = function(n) {
                return K("ouvrirGemstone", Y({}))
            }, n.segmentKrux = function(n) {
                return _ = "function" == typeof n ? n : null, K("segmentKrux", Y({}))
            }, n.rejeuParcours = function() {
                return K("rejeuParcours", Y({}))
            }, n.invaliderCache = function(n, t, e) {
                var o = {};
                return "" !== n && (o.cle = n), D = "function" == typeof t ? t : null, S = "function" == typeof e ? e : null, K("invaliderCache", Y(o))
            }, n.closeLoader = function(n, t) {
                return T = "function" == typeof n ? n : null, j = "function" == typeof t ? t : null, K("closeLoader", Y({}))
            }, n.downloadDocument = function(n) {
                var t = {};
                return t.url = n, K("downloadDocument", Y(t))
            }, n.renouvelerVirementPonctuel = function(n) {
                return "object" == typeof n && K("renouvelerVirementPonctuel", Y(n))
            }, n.getTrackingContextData = function(n, t) {
                L = "function" == typeof n ? n : null, B = "function" == typeof t ? t : null, K("getTrackingContextData", Y({}))
            }, n.isVersionAppliGreaterThanEqual = function(n) {
                if ("string" != typeof n) throw new TypeError("Invalid argument expected string");
                if (!new RegExp(q, "i").test(n)) throw new Error("Invalid argument not valid semver version ('" + n + "' received, pattern: x.x(.x)(.x))");
                var t, e, o, i, r, u = (i = "Version-Appli", r = document.cookie.match("(^|[^;]+)\\s*" + i + "\\s*=\\s*([^;]+)"), t = r ? r.pop() : "", e = new RegExp("^L%27Appli-(?:\\S+-)?OOB-BDDF-PRI-MOB%2F(" + q + ").*?%20%28", "i"), (o = t.match(e)) && o.length > 0 ? o[1] : null);
                return null === u ? (console.warn("versionAppli is null"), !1) : function(n, t) {
                    for (var e = n.split("."), o = t.split("."), i = 0; i < Math.max(e.length, o.length); i++) {
                        var r = parseInt(e[i] || 0, 10),
                            u = parseInt(o[i] || 0, 10);
                        if (r > u) return 1;
                        if (u > r) return -1
                    }
                    return 0
                }(u, n) >= 0
            }, n.estEnrole = function(n) {
                console.debug("Appel à la fonction <estEnrole> du module natif"), R = "function" == typeof n ? n : null;
                return K("estEnrole", Y({}))
            }, n.screenshot = function(n) {
                var t = {};
                return t.isAllowed = n, K("screenshot", Y(t))
            },
            function() {
                window.clickBackButton = function() {
                    try {
                        var n = document.getElementById("natif-settings"),
                            t = n ? n.getAttribute("data-natif-back") : null;
                        null != t && ("" == t ? window.history.back() : document.location.href = t)
                    } catch (n) {
                        G(n)
                    }
                };
                var q = {
                    segmentKruxCallback: function(n) {
                        if ("function" == typeof _) try {
                            _(n)
                        } finally {
                            _ = null
                        }
                    },
                    typeCameraCallback: function(n, t) {
                        if ("function" == typeof x) try {
                            x(n, t)
                        } finally {
                            x = null
                        }
                    },
                    uploadFichierSuccess: function() {
                        if ("function" == typeof k) try {
                            k()
                        } finally {
                            k = null, O = null
                        }
                    },
                    uploadFichierEchec: function() {
                        if ("function" == typeof O) try {
                            O()
                        } finally {
                            O = null, k = null
                        }
                    },
                    callbackActivateZoomSuccess: function() {
                        if ("function" == typeof A) try {
                            A()
                        } finally {
                            A = null, E = null
                        }
                    },
                    callbackActivateZoomEchec: function() {
                        if ("function" == typeof E) try {
                            E()
                        } finally {
                            E = null, A = null
                        }
                    },
                    callback_activerPassSecuriteSuccess: function() {
                        if ("function" == typeof C) try {
                            C()
                        } finally {
                            C = null, P = null
                        }
                    },
                    callback_activerPassSecuriteEchec: function() {
                        if ("function" == typeof P) try {
                            P()
                        } finally {
                            P = null, C = null
                        }
                    },
                    callback_debranchementEchec: function() {
                        if ("function" == typeof t) try {
                            t()
                        } finally {
                            t = null
                        }
                    },
                    getQRCodeScanSucces: function(n) {
                        if ("function" == typeof e) try {
                            e(n)
                        } finally {
                            e = null, o = null
                        }
                    },
                    getQRCodeScanEchec: function() {
                        if ("function" == typeof o) try {
                            o()
                        } finally {
                            o = null, e = null
                        }
                    },
                    clicPopinBouton1: function() {
                        if ("function" == typeof i) try {
                            i()
                        } finally {
                            i = null
                        }
                    },
                    clicPopinBouton2: function() {
                        if ("function" == typeof r) try {
                            r()
                        } finally {
                            r = null
                        }
                    },
                    callback_showDatePicker: function(n) {
                        if ("function" == typeof u) try {
                            u(n)
                        } finally {
                            u = null
                        }
                    },
                    callback_getSASObject: function(n) {
                        if ("function" == typeof l) try {
                            l(n)
                        } finally {
                            l = null
                        }
                    },
                    callback_getProfilTiers: function(n) {
                        if ("function" == typeof c) try {
                            c(n)
                        } finally {
                            c = null
                        }
                    },
                    priseDeVueSuccess: function(t, e) {
                        if ("function" == typeof a) try {
                            a(t, e)
                        } finally {
                            n.closeLoader(), a = null, f = null
                        }
                    },
                    priseDeVueEchec: function() {
                        if ("function" == typeof f) try {
                            f()
                        } finally {
                            f = null, a = null
                        }
                    },
                    callback_ouvrirPopinV2: function(n) {
                        if ("function" == typeof p) try {
                            p(n)
                        } finally {
                            p = null
                        }
                    },
                    prendreSelfieSuccess: function(n, t) {
                        if ("function" == typeof s) try {
                            s(n, t)
                        } finally {
                            s = null, d = null
                        }
                    },
                    prendreSelfieEchec: function() {
                        if ("function" == typeof d) try {
                            d()
                        } finally {
                            d = null, s = null
                        }
                    },
                    recupererImageSuccess: function(n, t) {
                        if ("function" == typeof w) try {
                            w(n, t)
                        } finally {
                            w = null, h = null
                        }
                    },
                    recupererImageEchec: function() {
                        if ("function" == typeof h) try {
                            h()
                        } finally {
                            h = null, w = null
                        }
                    },
                    demarrerDiscusionSuccess: function(n, t) {
                        if ("function" == typeof y) try {
                            y(n, t)
                        } finally {
                            y = null, v = null
                        }
                    },
                    demarrerDiscusionEchec: function() {
                        if ("function" == typeof v) try {
                            v()
                        } finally {
                            v = null, y = null
                        }
                    },
                    partagerVirementSuccess: function() {
                        if ("function" == typeof g) try {
                            g()
                        } finally {
                            g = null, m = null
                        }
                    },
                    partagerVirementError: function() {
                        if ("function" == typeof m) try {
                            m()
                        } finally {
                            m = null, g = null
                        }
                    },
                    closePleinEcranSucces: function() {
                        if ("function" == typeof b) try {
                            b()
                        } finally {
                            b = null
                        }
                    },
                    invaliderCacheSuccess: function() {
                        if ("function" == typeof D) try {
                            D()
                        } finally {
                            D = null, S = null
                        }
                    },
                    invaliderCacheEchec: function() {
                        if ("function" == typeof S) try {
                            S()
                        } finally {
                            S = null, D = null
                        }
                    },
                    closeLoaderSuccess: function() {
                        if ("function" == typeof T) try {
                            T()
                        } finally {
                            T = null, j = null
                        }
                    },
                    closeLoaderEchec: function() {
                        if ("function" == typeof j) try {
                            j()
                        } finally {
                            j = null, T = null
                        }
                    },
                    getTrackingContextDataSuccess: function(n) {
                        if ("function" == typeof L) try {
                            L(n)
                        } finally {
                            L = null, B = null
                        }
                    },
                    getTrackingContextDataError: function(n) {
                        if ("function" == typeof B) try {
                            B(n)
                        } finally {
                            B = null, L = null
                        }
                    },
                    typeConnexionCallback: function(n, t) {
                        "function" == typeof V && V(n, t)
                    },
                    disponibiliteAgentOui: function() {
                        "function" == typeof F && F()
                    },
                    disponibiliteAgentNon: function() {
                        "function" == typeof U && U()
                    },
                    clickContextualMenuButton: function() {
                        "function" == typeof N && N()
                    },
                    callback_menuContextuelRubriqueCliquee: function(n) {
                        if ("function" == typeof M) return M(n)
                    },
                    callback_webviewReady: function() {
                        return "function" == typeof I && I()
                    },
                    estEnroleReussie: function(n) {
                        "function" == typeof R && R(n = !0 === n || "true" === n)
                    }
                };
                for (var J in q) q.hasOwnProperty(J) && ("function" == typeof window[J] ? function(n, t) {
                    window[J] = function() {
                        n.apply(window, arguments), t.apply(window, arguments)
                    }
                }(q[J], window[J]) : window[J] = q[J])
            }();
        var q = "(0|[1-9]\\d*)\\.(0|[1-9]\\d*)(?:\\.(0|[1-9]\\d*))?(?:\\.(0|[1-9]\\d*))?";

        function J() {
            const n = window.navigator.userAgent.toLowerCase();
            return /android/.test(n)
        }

        function Q(n, t, e) {
            if (n && t && e)
                if (n[t]) e();
                else {
                    const o = Object.getOwnPropertyDescriptor(n, t) || {};
                    Object.defineProperty(n, t, {
                        configurable: !0,
                        enumerable: !0,
                        writeable: !0,
                        get: o.get || function() {
                            return this["_" + t]
                        },
                        set: function(n) {
                            o.set ? o.set.call(this, n) : this["_" + t] = n, n && e && (e(), e = null)
                        }
                    })
                }
        }

        function K(n, t) {
            try {
                Q(window, "native_interaction_method", function() {
                    G(null, "Appel natif method=<" + n + "> ; parameters=<" + t + ">"), window.native_interaction_method(n, t)
                })
            } catch (n) {
                return G(n), !1
            }
            return !0
        }
        window.setNativeInteractionMethod = function(n) {
            null == window.native_interaction_method && (window.native_interaction_method = n)
        };
        var H, Z, z, W, Y = window.JSON && window.JSON.stringify || function(n) {
                var t = typeof n;
                if ("object" != t || null === n) return "string" == t && (n = '"' + n + '"'), String(n);
                var e, o, i = [],
                    r = n && n.constructor == Array;
                for (e in n) "string" == (t = typeof(o = n[e])) ? o = '"' + o + '"' : "object" == t && null !== o && (o = Y(o)), i.push((r ? "" : '"' + e + '":') + String(o));
                return (r ? "[" : "{") + String(i) + (r ? "]" : "}")
            },
            X = navigator.userAgent.toLowerCase();
        if (0 === X.indexOf("l'appli") || (W = "Version-Appli", document.cookie.indexOf(W + "=") >= 0))
            if (J()) Q(window, "handlerJs", function() {
                Q(window.handlerJs, "callFromJavaScript", function() {
                    window.setNativeInteractionMethod(function(n, t) {
                        window.handlerJs.callFromJavaScript(n, t)
                    })
                })
            });
            else {
                window.setNativeInteractionMethod(function(n, t) {
                    var e = document.createElement("iframe");
                    e.setAttribute("src", "native/" + n + "?data=" + t), document.documentElement.appendChild(e), e.parentNode.removeChild(e), e = null
                }), H = window, Z = "load", z = function() {
                    n.initBarreNavigation()
                }, H.attachEvent ? H.attachEvent("on" + Z, z) : H.addEventListener(Z, z, !0)
            } else window.setNativeInteractionMethod(function() {
            window.awt_natif_not_supported_warned || (G(null, "setNativeInteractionMethod non supportée"), window.awt_natif_not_supported_warned = !0)
        });
        return n
    }.apply(t, [])) || (n.exports = o)
}, function(n, t, e) {
    "use strict";
    e.r(t);
    var o, i, r = e(0),
        u = e.n(r),
        l = null === (o = window) || void 0 === o ? void 0 : null === (i = o.console) || void 0 === i ? void 0 : i.log,
        c = function() {},
        a = function(n) {
            var t, e;
            return "function" == typeof(null === (t = window) || void 0 === t ? void 0 : null === (e = t.console) || void 0 === e ? void 0 : e[n]) ? function() {
                var t;
                return (t = window.console)[n].apply(t, arguments)
            } : "function" == typeof l ? function() {
                return l.apply(void 0, arguments)
            } : c
        },
        f = {
            debug: function() {
                a("debug").apply(void 0, arguments)
            },
            info: function() {
                a("info").apply(void 0, arguments)
            },
            warning: function() {
                a("warn").apply(void 0, arguments)
            },
            error: function() {
                a("error").apply(void 0, arguments)
            }
        },
        p = e(4),
        s = e.n(p),
        d = e(1),
        y = e.n(d),
        v = e(2),
        g = e.n(v),
        m = function(n, t, e) {
            window.tc_vars = window.tc_vars || {}, window.tc_vars[n] = e && window.tc_vars[n] || t
        },
        b = {
            DATA_LAYER_PROPS: {
                ENV_CONTAINER_PATH: "env_container_path"
            },
            updateDataLayerProp: m,
            updateDataLayerProps: function(n, t) {
                Object.keys(n).forEach(function(e) {
                    m(e, n[e], t)
                })
            }
        },
        w = {
            asyncLoadScript: function(n, t) {
                var e = document.createElement("script");
                e.type = "text/javascript", e.src = n, e.async = !0, document.head.appendChild(e), e.addEventListener("load", function() {
                    t()
                }), e.addEventListener("error", function(n) {
                    t(n)
                })
            }
        },
        h = b.DATA_LAYER_PROPS.ENV_CONTAINER_PATH,
        C = b.updateDataLayerProp,
        P = w.asyncLoadScript,
        x = {
            loadTmsMainContainer: function(n, t) {
                var e, o, i, r, u = (i = document.getElementsByTagName("script"), ((r = null === (e = Array.prototype.filter.call(i, function(n) {
                        var t;
                        return (null == n ? void 0 : null === (t = n.src) || void 0 === t ? void 0 : t.indexOf("../assets/js/public-tms.js")) >= 0
                    })) || void 0 === e ? void 0 : null === (o = e[0]) || void 0 === o ? void 0 : o.src) ? r.substring(0, r.indexOf("../assets/js/public-tms.js")) : "") + ""),
                    l = "".concat("../assets/js/tc_SocieteGenerale_20.js");
                C(h, u), P(l, function(e) {
                    e ? t("script fetch error ".concat(l)) : n()
                })
            },
            TMS_CONTAINER_FILE_NAME: "tc_SocieteGenerale_20.js"
        }.loadTmsMainContainer,
        A = [{
            name: "tmsReload"
        }, {
            name: "tmsEvent"
        }, {
            scope: "bddfTms",
            name: "trackPage"
        }, {
            scope: "bddfTms",
            name: "trackEvent"
        }, {
            name: "tc_events_20"
        }, {
            name: "xt_click"
        }, {
            scope: "tms",
            name: "trackEvent"
        }],
        E = function() {
            function n() {
                y()(this, n), this.pendingCalls = []
            }
            return g()(n, [{
                key: "loadTmsContainerApi",
                value: function() {
                    var n = this;
                    x(function() {
                        n.bindRealApi()
                    }, function(t) {
                        f.error("[publicTms]", t), n.bindRealApi()
                    })
                }
            }, {
                key: "initPendingApi",
                value: function() {
                    var n = this;
                    A.forEach(function(t) {
                        var e = t || {},
                            o = e.scope,
                            i = e.name;
                        o && !window[o] && (window[o] = {});
                        var r = o ? window[o] : window;
                        "function" == typeof r[i] ? f.info("[publicTms] : methode '".concat(o ? "".concat(o, ".") : "").concat(i, "' déjà présente")) : (r[i] = function() {
                            for (var e = arguments.length, o = new Array(e), i = 0; i < e; i++) o[i] = arguments[i];
                            n.pendingCalls.push({
                                method: t,
                                args: o
                            })
                        }, r[i].pending = !0)
                    })
                }
            }, {
                key: "bindRealApi",
                value: function() {
                    for (var n; void 0 !== (n = this.pendingCalls.shift());) {
                        var t, e = n || {},
                            o = e.method,
                            i = (o = void 0 === o ? {} : o).scope,
                            r = o.name,
                            u = e.args,
                            l = i ? null === (t = window) || void 0 === t ? void 0 : t[i] : window;
                        "function" != typeof l[r] || l[r].pending ? f.error("[publicTms] : method '".concat(i ? "".concat(i, ".") : "").concat(r, "' absente")) : l[r].apply(l, s()(u))
                    }
                    A.forEach(function(n) {
                        var t = n || {},
                            e = t.scope,
                            o = t.name,
                            i = e ? window[e] : window;
                        "function" == typeof i[o] && i[o].pending && (i[o] = function() {
                            f.error("[publicTms] : method '".concat(e ? "".concat(e, ".") : "").concat(o, "' absente"))
                        }, i[o].pending = null, i[o].error = !0)
                    })
                }
            }]), n
        }(),
        k = e(3),
        O = e.n(k);

    function _(n, t) {
        var e = Object.keys(n);
        if (Object.getOwnPropertySymbols) {
            var o = Object.getOwnPropertySymbols(n);
            t && (o = o.filter(function(t) {
                return Object.getOwnPropertyDescriptor(n, t).enumerable
            })), e.push.apply(e, o)
        }
        return e
    }
    var D = {
            formatAppliNativeContext: function(n) {
                return function(n) {
                    for (var t = 1; t < arguments.length; t++) {
                        var e = null != arguments[t] ? arguments[t] : {};
                        t % 2 ? _(Object(e), !0).forEach(function(t) {
                            u()(n, t, e[t])
                        }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(n, Object.getOwnPropertyDescriptors(e)) : _(Object(e)).forEach(function(t) {
                            Object.defineProperty(n, t, Object.getOwnPropertyDescriptor(e, t))
                        })
                    }
                    return n
                }({}, n, {
                    user_profil_tiers: (t = null == n ? void 0 : n.user_profil_tiers, t ? Object.keys(t).filter(function(n) {
                        return "true" === "".concat(t[n])
                    }).reduce(function(n, t, e) {
                        return "".concat(n).concat(e > 0 ? "-" : "").concat(t)
                    }, "") : "")
                });
                var t
            }
        }.formatAppliNativeContext,
        S = function() {
            function n() {
                y()(this, n), this.trackingContextData = null, this.trackingContextDataLoading = !1, this.trackingContextDataError = null, this.pendingCallbacks = []
            }
            return g()(n, [{
                key: "getTrackingContextData",
                value: function() {
                    var n = this,
                        t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : function() {};
                    if (!this.trackingContextDataError)
                        if (this.trackingContextData) t(this.trackingContextData);
                        else if (this.pendingCallbacks.push(t), !this.trackingContextDataLoading) {
                        if ("function" != typeof O.a.getTrackingContextData) return void f.warning("[publicTms] : incompatible 'awt-natif': method 'getTrackingContextData' is missing");
                        this.trackingContextDataLoading = !0, O.a.getTrackingContextData(function(t) {
                            n.trackingContextDataLoading = !1, n.trackingContextData = D(t), n.pendingCallbacks.forEach(function(t) {
                                t(n.trackingContextData)
                            })
                        }, function(t) {
                            f.warning("[publicTms] : natif.getTrackingContextData error", t), n.trackingContextDataLoading = !1, n.trackingContextDataError = t
                        })
                    }
                }
            }]), n
        }(),
        T = {
            getCookieValue: function(n) {
                var t = new RegExp("".concat(n, "=([^;]*)")).exec(document.cookie);
                return (null == t ? void 0 : t.length) >= 2 ? decodeURIComponent(t[1]) : null
            },
            getLocalStorageValue: function(n) {
                var t, e;
                return (null === (t = window) || void 0 === t ? void 0 : null === (e = t.localStorage) || void 0 === e ? void 0 : e.getItem(n)) || null
            },
            getUserAgent: function() {
                var n;
                return null === (n = navigator) || void 0 === n ? void 0 : n.userAgent
            }
        },
        j = T.getCookieValue,
        R = T.getUserAgent;

    function L(n, t) {
        var e = Object.keys(n);
        if (Object.getOwnPropertySymbols) {
            var o = Object.getOwnPropertySymbols(n);
            t && (o = o.filter(function(t) {
                return Object.getOwnPropertyDescriptor(n, t).enumerable
            })), e.push.apply(e, o)
        }
        return e
    }
    var B = {
            isAppliNative: function() {
                var n;
                return j("Version-Appli") || 0 === (null === (n = R()) || void 0 === n ? void 0 : n.indexOf("L'Appli-OOB-BDDF"))
            }
        }.isAppliNative,
        I = b.updateDataLayerProps,
        N = new E,
        M = new S;
    window.bddfTms ? f.warning("[publicTms] : Script public déjà chargé et présent dans la page") : (f.info("[publicTms] : Chargement du container"), N.initPendingApi(), B() ? M.getTrackingContextData(function(n) {
        I(function(n) {
            for (var t = 1; t < arguments.length; t++) {
                var e = null != arguments[t] ? arguments[t] : {};
                t % 2 ? L(Object(e), !0).forEach(function(t) {
                    u()(n, t, e[t])
                }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(n, Object.getOwnPropertyDescriptors(e)) : L(Object(e)).forEach(function(t) {
                    Object.defineProperty(n, t, Object.getOwnPropertyDescriptor(e, t))
                })
            }
            return n
        }({}, n, {
            env_channel: "webview",
            env_is_private: !0
        })), N.loadTmsContainerApi()
    }) : N.loadTmsContainerApi())
}]);